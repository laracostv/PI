var winH = $(window).height();
var winW = $(window).width();


$(window).resize(function() {
	responsive();
});
$(window).ready(function() {
	responsive();
});


function responsive(){
	var winH = $(window).height();
	var winW = $(window).width();
	$('body').css('height', (winH) + 'px');
	if(winW <= 768){
		$('#cad-rst').hide();
		$('#bar-down').show();
	}else{
		$('#cad-rst').show();
		$('#bar-down').hide();
	}
}



function formChange(id){
	if (id == 0) {
		$('body').css('overflow-y','hidden');
		$('#login-form').slideDown();
		$('#cad-form').fadeOut(200);
		$('#cad-but').fadeIn(200);
		$('.box').css('height', 250 + 'px');
		$('.box').css('margin-top', 40 + '%');
	}
	if (id == 1) {
		$('#titl').fadeIn();
		$('#ret-but').fadeIn();
		$('#login-form').slideUp();
		$('#cad-but').fadeOut(200);
		$('#clas').fadeIn(500);
	}
	if (id == 2) {
		$('body').css('overflow-y','hidden');
		$('#ret-but').hide();
		$('#ret-but-2').show();
		$('#clas').slideUp(400);
		$('#prox1').fadeOut(200);
		$('#cad-form').fadeIn(500);
		$('.box').css('height', 450 + 'px');
		$('.box').css('margin-top', 10 + '%');
	}
	//$('body').css('overflow-y','auto');
}

function formReturn(id){
	if (id = 1) {
		$('body').css('overflow-y','hidden');
		$('#titl').fadeOut();
		$('#ret-but').hide();
		$('#login-form').slideDown();
		$('#cad-but').fadeIn(200);
		$('#clas').fadeOut(200);
		$('.box').css('height', 250 + 'px');
		$('.box').css('margin-top', 40 + '%');
	}
}

function onlyNumbers(e){
	var charCode = e.charCode ? e.charCode : e.keyCode;
		 // charCode 8 = backspace   
		 // charCode 9 = tab
		 if (charCode != 8 && charCode != 9) {
			 // charCode 48 equivale a 0   
			 // charCode 57 equivale a 9
			 if (charCode < 48 || charCode > 57) {
				 /*
				 if(charCode == 40 || charCode == 41 || charCode == 45){
					 return true;
				 }*/
				 return false;
			 }
		 }
 }


 $(document).ready(function(){
	$('#cel').mask('(00) 00000-0000');
	$('#dateN').mask('00/00/0000');
});

$(document).ready(function(){
    $('#btnLogin').click(function(){
      var emptyField = false;

      if($('#userEmail').val() == ''){
		$('#userEmail').css('border-bottom', '2px solid #f23838');
		$('#text-erro').text('Preencha todos os campos');
        emptyField = true;
      }else{
		$('#userEmail').css('background', '#ffffff');
	  }
      if($('#pasw').val() == ''){
		$('#pasw').css('border-bottom', '2px solid #f23838');
		$('#text-erro').text('Preencha todos os campos');
        emptyField = true;
      }else{
		$('#pasw').css('background', '#ffffff');
	  }

      if(emptyField) return false;
	});
});

function alertMenssage(){
	Swal.fire({
	  title: 'Opaaa',
	  text: 'Você precisa estar logado para acessar esta página',
	  icon: 'warning',
	  confirmButtonText: 'Entendi!',
	  focusConfirm: false,
	  confirmButtonColor: '#00a39b',
	})
  }

function alertMenssageCad(){
	Swal.fire({
	  title: 'Opaaa',
	  text: 'Parece que você está utilizando um email já cadastrado',
	  icon: 'warning',
	  confirmButtonText: 'Entendi!',
	  focusConfirm: false,
	  confirmButtonColor: '#00a39b',
	})
  }

  $(document).ready(function(){
	$('#up_image').change(function(){
		const file = $(this)[0].files[0]
		const fileReader = new FileReader();
		fileReader.onloadend = function(){
			src = 'url("'+fileReader.result+'")'
			console.log(src)
			$('.fileUpload').css('background-image', src);
		}
		fileReader.readAsDataURL(file);
	})
  }) 