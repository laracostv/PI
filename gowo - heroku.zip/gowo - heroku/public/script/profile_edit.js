$(document).ready(function(){
	$('#cel').mask('(00) 00000-0000');
    $('#dateN').mask('00/00/0000');
    
    $('#btn-edit').click(function(){
        $('#name').prop("readonly", false);
        $('#last-name').prop("readonly", false);
        $('#userEmail').prop("readonly", false);
        $('#dateN').prop("readonly", false);
        $('#cel').prop("readonly", false);
        $('#pasw').prop("readonly", false);
        $('input').css('background-color', '#ffffff')
        $('.but').css('background-color', '#00a39b')
        $('#btn-edit').hide();
        $('#btn-send').show();
    })

});

function confirmMessage(){
    Swal.fire({
        title: 'Perfil Atualizado!',
        text: 'dados cadastrais atualziados com sucesso :)',
        icon: 'success',
        confirmButtonText: 'Continuar',
        focusConfirm: false,
        confirmButtonColor: '#00a39b',        
      })
}

function errorMessage(){
    Swal.fire({
        title: 'Opss..',
        text: 'Parece que algo deu errado tente novamente!',
        icon: 'warning',
        confirmButtonText: 'Continuar',
        focusConfirm: false,
        confirmButtonColor: '#00a39b',        
      })
}