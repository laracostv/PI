function message_input(id){
    console.log(id.rows)
    if(id.scrollHeight > id.offsetHeight){
        id.rows += 1;
    }
}