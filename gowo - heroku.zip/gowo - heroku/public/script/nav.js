function navRed(id){
    if(id == 1){
        window.location.href = "../store";
    }
    if(id == 2){
        window.location.href = "../chat";
    }
    if(id == 3){
        window.location.href = "../recents";
    }
    if(id == 4){
        window.location.href = "../profile";
    }
}

    //second level redirect

function navRedSecond(id){
    if(id == 1){
        window.location.href = "../../store";
    }
    if(id == 2){
        window.location.href = "../../chat";
    }
    if(id == 3){
        window.location.href = "../../recents";
    }
    if(id == 4){
        window.location.href = "../../profile";
    }
}

function navRedThird(id){
    if(id == 1){
        window.location.href = "../../../store";
    }
    if(id == 2){
        window.location.href = "../../../chat";
    }
    if(id == 3){
        window.location.href = "../../../recents";
    }
    if(id == 4){
        window.location.href = "../../../profile";
    }
}

function redirect(id){
    if(id == 1){
        window.location.href = "addlocal";
    }
    if(id == 2){
        window.location.href = "cart";
    }
    if(id == 3){
        window.location.href = "../cart";
    }
}