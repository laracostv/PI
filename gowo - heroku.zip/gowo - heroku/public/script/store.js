function adressFunction(){
    $('#all-page').hide();
    $('#return-chevron').show()
    $('#all-adress').fadeIn(400)
}

function search(){
    $('#adress-box').slideUp(500);
    $('#allContent').fadeOut(500);
    $('#navigation-bar-down').fadeOut(100);
    $('#return-chevron').show()
}

function returnMain(id){
    if(id == 1){
        $('#all-page').fadeIn(100);
        $('#return-chevron').hide();
        $('#all-adress').hide();
        $('#adress-box').slideDown(500);
        $('#allContent').fadeIn(500);
        $('#navigation-bar-down').fadeIn(100);
    }
}

$(document).ready(function(){
    $("#search-input").focusout(function(){
        var tmnh = $('#search-input').val().length;
        if(tmnh == 0){
            returnMain(1);
        }
    });
});

function confirmMessage(){
    Swal.fire({
        title: 'Cadastrado',
        text: 'Seu novo endereço foi cadastrado',
        icon: 'success',
        confirmButtonText: 'Continuar',
        focusConfirm: false,
        confirmButtonColor: '#00a39b',        
      })
}

function addFistLocal(){
    Swal.fire({
        title: '<h2><b>Bem vindo!</b></h2>',
        html:
        '<p class="wellcome-message">Ficamos felizes em ter você aqui!</p>' +
        '<p class="wellcome-desc"> Adicione um local para que possa obter resultados com base na sua região</p>',
        icon: 'success',
        confirmButtonText: '<a class="no-decoration" href="../store/addlocal">Adionar</a>',
        focusConfirm: false,
        confirmButtonColor: '#00a39b',        
      })
}