/*
$(document).ready(function(){
    $("#txtCep").focusout(function(){
        consultCep();
    });
});
*/
function confirmMessage(){
    Swal.fire({
        title: 'Cadastrado',
        text: 'Seu novo endereço foi e você retornará para pagina pricipal',
        icon: 'success',
        confirmButtonText: 'Continuar',
        focusConfirm: false,
        confirmButtonColor: '#00a39b',
        timer: 5000,
        timerProgressBar: true,
        onClose: () => {
            window.location.href = "../../store";
          }
        }).then((result) => {
          if (
            /* Read more about handling dismissals below */
            result.dismiss === Swal.DismissReason.timer
          ) {
            console.log('redirect failed') // eslint-disable-line
          }
      })
}

var listEnd = []

function callFunctionCep(){
    var size = $('#txtCep').val().length;
    if (size == 9){
        consultCep()
        $('#txtCep').blur();
    }
    if(size < 9){
        $('#complete-local').fadeOut();
    }
}

function consultCep(){
    $('#loader').show()
    var cep = $("#txtCep").val();
    var cep2 = $("#cep-searched").val();
    if (cep.length == 0){
        cep = cep2;
    }
    cep = cep.replace("-", "");
    var urlStr = "https://viacep.com.br/ws/"+ cep +"/json/";
 
    $.ajax({
        url : urlStr,
        type : "get",
        dataType : "json",
        success : function(data){
            if (data.erro){
                errorCepReturn();
            }else{
            var lograd = data.logradouro;
            var bair = data.bairro;
            $('#loader').hide()
            $('#incorret-cep').hide();
            $('#complete-local').fadeIn();
            $('#txtCep').removeClass('invalid-feedback-box')
            $('#instructions').hide()

            if(lograd != ''){
                $("#end").prop("readonly", true);
                $('#nmr').focus();
                clickFocus(1);
            }else{
                $("#end").prop("readonly", false);
                $('#end').focus();
                clickFocus(2);
            }
            if(bair != ''){
                $("#bairro").prop("readonly", true);
                console.log('save')
            }else{
                $("#bairro").prop("readonly", false);
                console.log('save')
            }

            $("#city").prop("readonly", true);
            $("#estado").prop("readonly", true);                 

            $("#end").val(data.logradouro);               
            $("#bairro").val(data.bairro);
            $("#city").val(data.localidade);
            $("#estado").val(data.uf);                    
            $("#complemento").val(data.complemento);
            }
        },
        error : function(erro){
            console.log(erro);
            errorCepReturn();
        }
    });
}

function clickFocus(id){
    if (id == 1){
        document.getElementById('myHiddenButtonNmr').click();
    }
    if (id == 2){
        document.getElementById('myHiddenButtonEnd').click();
    }
}

function doFocus(id){
    if (id == 1){
        var focusElementId = "end"
        var textBox = document.getElementById(focusElementId);
        textBox.focus();
    }
    if (id == 2){
        var focusElementId = "nmr"
        var textBox = document.getElementById(focusElementId);
        textBox.focus();
    }
}

function errorCepReturn(){
    $('#loader').hide();
    $('#incorret-cep').show();
    $('#complete-local').fadeOut();
    $('#txtCep').addClass('invalid-feedback-box')
}


$(document).ready(function(){
    $('#txtCep').mask('00000-000');
});

function onlyNumbers(e){
   var charCode = e.charCode ? e.charCode : e.keyCode;
        // charCode 8 = backspace   
        // charCode 9 = tab
        if (charCode != 8 && charCode != 9) {
            // charCode 48 equivale a 0   
            // charCode 57 equivale a 9
            if (charCode < 48 || charCode > 57) {
                return false;
            }
        }
}

function discoverCEP_input(){
    $('#cep-group').slideUp();
    $('#instructions-txt').hide();
    $('#discoverCEP').fadeIn();
}

$(document).keyup(function(){
    allCompleted();
    allCompletedSearch()
});

function allCompleted(){
    var tcep = $("#txtCep").val().length; 
    var end  = $("#end").val().length;
    var nmr  = $("#nmr").val().length;            
    var bir  = $("#bairro").val().length;
    var cit  = $("#city").val().length;
    var est  = $("#estado").val().length;

    if(tcep == 9 && end > 0 && nmr > 0 && bir > 0 && cit > 0 && est == 2){
        $("#btn-save").prop("disabled", false);
        //console.log('libera');
    }else{
        $("#btn-save").prop("disabled", true);
        //console.log('block');
    }
}

function allCompletedSearch(){
    var s_est =  $("#estado-c").val().length;
    var s_cit =  $("#city-c").val().length;
    var s_end =  $("#end-c").val().length;

    if(s_est == 2 && s_cit > 0 && s_end > 0){
        $("#btn-consult").prop("disabled", false);
    }else{
        $("#btn-consult").prop("disabled", true);
    }
}

function searchCEP(){
    $('#point-loader').show();
    $('#results').hide();
    var uf = $("#estado-c").val();
    var ci = $("#city-c").val();
    var lo = $("#end-c").val();
    var urlStrCep = "https://viacep.com.br/ws/"+ uf + "/"+ ci +"/"+ lo +"/json/";

    $.ajax({
        url : urlStrCep,
        type : "get",
        dataType : "json",
        success : function(data){
            $('#results').show();
            if (data.length == 0){
                $('#point-loader').hide();
                $('#error-mensage-search').show();
                $('#results').hide();
            }else{
                listEnd = [];
                //console.log(data)
                $('#error-mensage-search').hide();
                $('#point-loader').hide();
                $('#result-text').fadeIn();
                if(data.length == 1){
                    $('#result-text').html('1 resultado encontrado');
                }else{
                    $('#result-text').html(data.length + ' resultados encontrados');
                }
                $('#list_results').html('')
                for(var i=0; i < data.length; i++){
                    var cep = data[i].cep;
                    var log = data[i].logradouro;
                    var loc = data[i].localidade;
                    var est = data[i].uf;
                    var bai = data[i].bairro;

                    var endItem = [];
                    endItem.push(cep);
                    endItem.push(log);
                    endItem.push(loc);
                    endItem.push(est);
                    endItem.push(bai);

                    listEnd.push(endItem);

                    if(log.length > 0){
                        log = log + ', '
                    }
                    listResults(i, cep, log, loc, est, bai);
                }
            }
        },
        error : function(erro){
            console.log(erro);
            $('#point-loader').hide();
            $('#error-mensage-search').show();
            $('#results').hide();
        }
    });
}

function listResults(id, cep, log, loc, uf, bai){
    $('#list_results').append('<div class="adress-select" id="r'+id+'" onclick="completeEnd('+id+')">'+
    '<i data-feather="map-pin" class="local-icon"></i>'+
    '<div class="adress-description">'+
        '<div class="adress-title">'+
            cep +
        '</div>'+
        '<div class="adress-complete">'+ 
            log + loc + ' - ' + uf +
        '</div>' +
        '<div class="adress-complement">'+
            bai +
        '</div>'+
    '</div>'+
'</div>')
feather.replace();
}

function completeEnd(id){
    $('#instructions').fadeOut();
    $('#cep-searched').show();
    $("#cep-s").val(listEnd[id][0]);
    $("#txtCep").val(listEnd[id][0]);
    $("#cep-s").prop('readonly', true);
    consultCep();
    //console.log(listEnd[id])
    $('#complete-local').show();
}