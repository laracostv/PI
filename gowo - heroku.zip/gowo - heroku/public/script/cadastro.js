function pwd_check(){
    var pwd = $('#pwd').val()
    var regexA = /^(?=(?:.*?[A-Z]))(?=(?:.*?[a-z]))/;
    var regexNum = /^(?=(?:.*?[0-9]))/;
    //const icon1 = $('#icon1');

    if(pwd.length < 6)
    {   
        $('#checkIcon1').hide();
        $('#icon1').show();
        $('#check1').css('color', '#ff6767')
    }
    if(!regexA.exec(pwd))
    {   
        $('#checkIcon2').hide();
        $('#icon2').show();
        $('#check2').css('color', '#ff6767')
    }
    if(!regexNum.exec(pwd))
    {   
        $('#checkIcon3').hide();
        $('#icon3').show();
        $('#check3').css('color', '#ff6767')
    }

    if(pwd.length >= 6){
        //icon1.replaceWith(feather.icons['check-circle'].toSvg());
        $('#icon1').hide();
        $('#checkIcon1').show();
        $('#check1').css('color', '#00a508')  
    }
    if(regexA.exec(pwd)){
        $('#icon2').hide();
        $('#checkIcon2').show();
        $('#check2').css('color', '#00a508')
    }
    if(regexNum.exec(pwd)){
        $('#icon3').hide();
        $('#checkIcon3').show();
        $('#check3').css('color', '#00a508')
    }

    return true;
}

function open_req(){
    $('.pwd-req').show(400);
    responsive();
}