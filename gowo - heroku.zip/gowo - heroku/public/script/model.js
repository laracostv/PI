var winW = window.innerWidth;
//console.log(winW);
var listPos = [];
var topicLength = 6;
var topicAnt = '#topicLink1';
var atual = 1;
var barW = 0;

function scrollPageDiv(id){
    if(winW > 992){
        if (id == 1){
            $('#box-inf').css('top', '100px');
            $('#box-inf').css('position', 'fixed');
            $('#inf-profile').slideDown();
            $('#box-inf').addClass('floating-box-shadow');
        }else{
            $('#box-inf').css('top', 'auto');
            $('#box-inf').css('position', 'relative');
            $('#box-inf').removeClass('floating-box-shadow');
            $('#inf-profile').hide();           
        }
    }else{
        //alert('pequeno')
        $('#inf-profile').hide();
    }
}

function headerScroll(id){
    if(id == 1){
        $('#logo-gowo').hide()
        $('#str-header').fadeIn();
        $('#bar-store').fadeIn();
    }else{
        $('#str-header').hide()
        $('#logo-gowo').fadeIn();
        $('#bar-store').fadeOut();
    }
}

function redirectMaps(end){
    linkAdressMaps = end.replace(/ /g,'+');
    linkAdressMaps = 'https://www.google.com.br/maps/place/' + linkAdressMaps;
    window.open(linkAdressMaps, '_blank');
}

$(document).ready(function(){
    scrollPageDiv();
    progressiveBar();
    walkingBar();
    $('.topics').css('width', (28*winW/412) + 'em')
});

function walkingBar(){
    console.log('tem que andar campeão')
}

$(function() {
    $(window).on("scroll", function() {
      if($(window).scrollTop() > 300) {
        scrollPageDiv(1);      
      } else {
        scrollPageDiv(2);
      }
    });
  });

  $(window).on("scroll", function() {
    valueScroll = $(window).scrollTop();
    
    if(valueScroll > 200) {
        headerScroll(1);
        barW = $('#topics').width();     
    } else {
        headerScroll(2);
    }

    for(var x = 1; x <= topicLength; x++){
        if(valueScroll >= listPos[x]){
            topicAnt = '#topicLink' + (x+1);
            atual = '#topicLink' + x;
            //console.log('Anterior', topicAnt )
            //console.log('Atual', atual )
            //console.log(' ')
            $(topicAnt).removeClass('active-topic');
            $(atual).addClass('active-topic');
        }
    }
    for(var y = 1; y <= topicLength; y++){
        if(valueScroll >= listPos[y]){
            topicAnt = '#topicLink' + (y-1);
            atual = '#topicLink' + y;
            //console.log('Anterior', topicAnt )
            //console.log('Atual', atual )
            //console.log(' ',)
            $(topicAnt).removeClass('active-topic');
            $(atual).addClass('active-topic');
        }
    }


  });

  $(document).ready(function(){
    var posicaoAtual = $(window).scrollTop();
    var documentSize = $(document).height();
    var sizeWindow = $(window).height();
    
    $(window).scroll(function () {
      posicaoAtual = $(window).scrollTop();
      position = documentSize - sizeWindow;
      if (winW < 768) {
        position = documentSize - sizeWindow - 60;
      }
        if ( posicaoAtual >=  position) {
            topicAnt = '#topicLink' + (topicLength-1);
            atual = '#topicLink' + (topicLength);
            $(topicAnt).removeClass('active-topic');
            $(atual).addClass('active-topic');
      }
    });
  });

  $(window).on("resize",function() {
    winW = window.innerWidth;
        if($(window).scrollTop() > 300) {
            scrollPageDiv(1);      
        } else {
            scrollPageDiv(2);
        }
    progressiveBar()
    $('.topics').css('width', (28*winW/412) + 'em')
  });

  function progressiveBar(){
    listPos = [];
    for(var i = 1; i <= topicLength; i++){
        topicId = '#topic' + i;
        dTop = $(topicId).offset().top-580;
        //console.log(dTop);
        listPos.push(dTop);
        //console.log(listPos);
      }
  }

  function toTop(){
    $('html, body').animate({ scrollTop: 0 }, 500);
  }

  $(document).on('click', 'a[href^="#"]', function (event) {
    event.preventDefault();
    $('html, body').animate({
        scrollTop: $($.attr(this, 'href')).offset().top-100
    }, 500);
});

    function topicH(id){
        alert(id);
    }
/*
$(document).on('click', '.topic-item', function (event) {
    $(topicAnt).removeClass('active-topic');
    $(this).addClass('active-topic');
    topicAnt = $(this).attr('id');
    topicAnt = "#" + topicAnt;
});
*/