<?php
session_start();
if(isset($_SESSION['email'])){
    header('Location: views/store');
}

  $erro = isset($_GET['erro']) ? $_GET['erro'] : 0;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-png">
  <!--FAVICONS-->
  <link rel="shortcut icon" href="assets/icons/favicon-512x512.png" type="image/x-png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/icons/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/icons/favicon-16x16.png">
  <link rel="manifest" href="assets/icons/site.webmanifest">
  <link rel="mask-icon" href="assets/icons/safari-pinned-tab.svg" color="#5bbad5">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="theme-color" content="#ffffff">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="public/css/general.css">
  <link rel="stylesheet" type="text/css" href="public/css/index.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="public/script/index.js"></script> 
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

</head>
<body id="fundo">
<script>

</script>
<div class="imgFundo">
<a href="views/inicial/store_register_page.php">
  <div class="cad-rst hidden-xs hidden-sm">Cadastre seu estabelecimento</div>
</a>
  <center>
    <img src="assets/images/logos/logo-gowo-h120.png" class="logo-gowo">
  </center>
  <div class="container">
    <div class="row">
      <div class="col-md-4 "></div>
      <div class="col-md-4">
        <center>
          <div class="center-box">
            <div class="box">
            <form id="login-form" method="post" action="data_base/login_validation.php">
              <input type="text" id="userEmail" name="user" placeholder="Email">
              <input type="password" id="pasw" name="pwd" placeholder="Senha">
              <?php
                if($erro == 1){
                  echo'<div class="text-erro" id="text-erro">Usuário e/ou senha incorretos</div>';
                }
                if($erro == 2){
                  echo"<script>
                  $(document).ready(function(){
                      responsive();
                      alertMenssage();
                    });
                  </script>";
                }
              ?>
              <div class="text-erro" id="text-erro"></div>
              <input type="submit" value="Entrar" name="submit" class="but" id="btnLogin">
            </form>
            <div class="text-cad">Ainda não possui conta?</div>
            <a href="views/inicial/cadastro.php" class="cad-click">Cadastre-se</a>

            <i class="fas fa-arrow-left return-arrow" onclick="formReturn(1)" id="ret-but"></i>
            <i class="fas fa-arrow-left return-arrow" onclick="formReturn(2)" id="ret-but-2"></i>

            <div class="title" id="titl" style="width: 120px;">CADASTRO</div>
            <div class="classification" id="clas">
              <div class="boxType" onclick="formChange(2)">
                <div class="contentBox">
                  <div class="icon-p">
                    <i class="far fa-user"></i>
                  </div>
                    Pessoa Física
                </div>
              </div>
              <div class="boxType" onclick="formChange(2.1)">
                <div class="contentBox">
                  <div class="icon-p">
                    <i class="far fa-building icon-p"></i>
                  </div>
                    Estabelecimento
                </div>
              </div>
            </div>
          </div>
        </center>
      </div>
    </div>
 </div>
  <div class="bar-down">
    <div></div>
  <center><a href="views/inicial/store_register_page.php"><button class="cad-rst-center hidden-md hidden-lg">Cadastre seu estabelecimento</button></a></center>
  </div>
  <!--
  <img src="assets/images/producao/dog1.png" class="img1">
  <img src="assets/images/producao/cat1.png" class="img2">
  <img src="assets/images/producao/hamis1.png" class="img3">
  -->
</div>
</body>
</html>