<?php
    session_start();

    unset($_SESSION['email']);
    unset($_SESSION['store_email']);
    unset($_SESSION['name']);
    unset($_SESSION['store_name']);
    unset($_SESSION['last-name']);
    unset($_SESSION['dateN']);
    unset($_SESSION['id_usr']);
    unset($_SESSION['id_usr']);

    header('Location: ../index.php')
?>