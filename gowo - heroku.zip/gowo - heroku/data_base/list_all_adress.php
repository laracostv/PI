<?php
    require_once('db.class.php');
    
    $id_usr = $_SESSION['id_usr'];
    $sql = "SELECT * FROM adressusers where id_user = '$id_usr'";

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $result_id = mysqli_query($link, $sql);

    if($result_id){
        $user_data = array();
        
        while($line = mysqli_fetch_array($result_id, MYSQLI_ASSOC)){
            $user_data[] = $line;
        }
        
        foreach($user_data as $user){
            echo'<div class="adress-select" id="adress-3">
            <i data-feather="map-pin" class="local-icon"></i>
            <div class="adress-description">
                <div class="adress-title">
                    '.$user['adress'].'
                </div>
                <div class="adress-complete">
                    '.$user['adress'].', '.$user['number'].', '.$user['nbh'].', '.$user['city'].' - '.$user['state'].'
                </div>
                <div class="adress-complement">
                '.$user['complement'].'
                </div>
            </div>
        </div>';
        }
        
    }else{
        echo"Erro ao entrar entre em contato com o suporte";
    }    
?>