<?php
    require_once('db.class.php');

    $sql = "SELECT * FROM stores";

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $result_id = mysqli_query($link, $sql);

    if($result_id){
        $user_data = array();
        
        while($line = mysqli_fetch_array($result_id, MYSQLI_ASSOC)){
            $user_data[] = $line;
        }
        
        foreach($user_data as $user){
            echo'<a style="text-decoration: none;" href="pages/pagemodel.php">            
            <div class="col-md-6 store-box">
                <img src="../../assets/images/all-images/store-profile/'.$user['profile_store_img'].'" class="store-profile">              
                <div class="desc-store">
                    <div class="store-name">'.$user['store_name'].'</div>
                    <div class="classification">
                        <div class="text-classification"><i data-feather="star" class="star-icon-store"></i> 4,9 - '.$user['store_class'].'</div>
                    </div>
                    <div class="store-text">Jardim Camburi - Vitória</div>
                </div>
            </div>
            </a>';
        }
        
    }else{
        echo"Erro ao entrar entre em contato com o suporte";
    }    
?>