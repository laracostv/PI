<?php
    session_start();
    require_once('db.class.php');

    $name = $_POST ['name'];
    $last_name = $_POST ['last_name'];
    $email = $_POST ['email'];
    $dateN = $_POST ['dateN'];
    $cell = $_POST ['cell'];
    $pwd = md5($_POST ['pwd']);
    $id_usr = $_SESSION['id_usr'];

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $sql = "UPDATE users SET name='$name', last_name='$last_name', email='$email', pwd='$pwd', cellPhone='$cell', dateN='$dateN' WHERE id='$id_usr'";

    if(mysqli_query($link,$sql)){
        header('Location: ../views/profile/pages/edit_profile/?protocol=1');
    }else{
        header('Location: ../views/profile/pages/edit_profile/?protocol=2');
        /*
        echo 'Código de erro:'.mysqli_errno( $link ).'<br>';
        echo 'Mensagem de erro:'.mysqli_error( $link ).'<br>';
        */
    }
?>