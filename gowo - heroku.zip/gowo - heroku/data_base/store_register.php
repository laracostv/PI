<?php

    require_once('db.class.php');
    include_once('db.class.php');

    $store_name = $_POST ['store_name'];
    $store_class = $_POST ['store_class'];
    $store_email = $_POST ['store_email'];
    $store_pwd = md5($_POST ['store_pwd']);
    $store_tel = $_POST ['store_tel'];

    $existent_email = false;

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $sql = " select * from stores where store_email ='$store_email'";

    if($id_result = mysqli_query($link, $sql)){
        $data_ver_usr = mysqli_fetch_array($id_result);

        if(isset($data_ver_usr['email'])){
            $existent_email = true;
        }
    }else{
        echo 'Erro ao tentar autenticar dados';
    };

    if($existent_email){
        $get_return = '?email_exist=1&';
        header('Location: ../views/inicial/store_register_page.php'.$get_return);
        die();
    }

        $arquivo = $_FILES['arquivo']['name'];
			
			//Pasta onde o arquivo vai ser salvo
			$_UP['pasta'] = '../assets/images/all-images/store-profile/';
			
			//Tamanho máximo do arquivo em Bytes
			$_UP['tamanho'] = 1024*1024*100; //5mb
			
			//Array com a extensões permitidas
			$_UP['extensoes'] = array('png', 'jpg', 'jpeg', 'gif');
			
			//Renomeiar
			$_UP['renomeia'] = true;
			
			//Array com os tipos de erros de upload do PHP
			$_UP['erros'][0] = 'Não houve erro';
			$_UP['erros'][1] = 'O arquivo no upload é maior que o limite do PHP';
			$_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especificado no HTML';
			$_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente';
			$_UP['erros'][4] = 'Não foi feito o upload do arquivo';
			
			//Verifica se houve algum erro com o upload. Sem sim, exibe a mensagem do erro
			if($_FILES['arquivo']['error'] != 0){
				die("Não foi possivel fazer o upload, erro: <br />". $_UP['erros'][$_FILES['arquivo']['error']]);
				exit; //Para a execução do script
			}
			
			//Faz a verificação da extensao do arquivo
            $tmp_format = explode('.', $_FILES['arquivo']['name']);
			$extensao = strtolower(end($tmp_format));
			if(array_search($extensao, $_UP['extensoes']) === false){		
				echo "
					<script type=\"text/javascript\">
						alert(\"A imagem não foi cadastrada extensão inválida.\");
					</script>
				";
			}
			
			//Faz a verificação do tamanho do arquivo
			else if ($_UP['tamanho'] < $_FILES['arquivo']['size']){
				echo "
					<script type=\"text/javascript\">
						alert(\"Arquivo muito grande.\");
					</script>
				";
			}
			
			//O arquivo passou em todas as verificações, hora de tentar move-lo para a pasta foto
			else{
				//Primeiro verifica se deve trocar o nome do arquivo
				if($_UP['renomeia'] == true){
					//Cria um nome baseado no UNIX TIMESTAMP atual e com extensão .jpg
                    $nome_final = md5(time()).'.jpg';
                    
				}else{
					//mantem o nome original do arquivo
					$nome_final = $_FILES['arquivo']['name'];
				}
				//Verificar se é possivel mover o arquivo para a pasta escolhida
				if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'].$nome_final)){
                    //Upload efetuado com sucesso, exibe a mensagem
                    $blank_var = true;
				}else{
					//Upload não efetuado com sucesso, exibe a mensagem
					echo "
						<script type=\"text/javascript\">
							alert(\"Imagem não foi cadastrada com Sucesso.\");
                        </script>
                    ";
                    die();
				}
			}


    $sql = "insert into stores(store_email, store_name, store_pwd, store_tel, store_class, store_owner_id, profile_store_img) values ('$store_email', '$store_name', '$store_pwd', '$store_tel', '$store_class', '0', '$nome_final')";

    if(mysqli_query($link,  $sql)){
        session_start();
        $sql = "SELECT * FROM stores WHERE store_email = '$store_email' AND store_pwd = '$store_pwd'";

        $objDb = new db();
        $link = $objDb->mysql_connect();

        $result_id = mysqli_query($link, $sql);
        if($result_id){
            $user_data = mysqli_fetch_array($result_id);
            if(isset($user_data['store_email'])){

                $_SESSION['store_name'] = $user_data['store_name'];
                $_SESSION['store_class'] = $user_data['store_class'];
                $_SESSION['store_email'] = $user_data['store_email'];
                $_SESSION['store_tel'] = $user_data['store_tel'];
                $_SESSION['store_img'] = $user_data['profile_store_img'];
                $_SESSION['store_id'] = $user_data['id'];
                
                if(mysqli_query($link,  $sql)){
                    header('Location: ../views/store');
                }else{
                    echo'Erro de protocolo ao cadastrar loja';
                    echo 'Código de erro:'.mysqli_errno( $link ).'<br>';
                    echo 'Mensagem de erro:'.mysqli_error( $link ).'<br>';   
                }          
            }
        }}
        else{
        echo'Erro de protocolo ao cadastrar loja';
        echo 'Código de erro:'.mysqli_errno( $link ).'<br>';
        echo 'Mensagem de erro:'.mysqli_error( $link ).'<br>';        
        }
?>