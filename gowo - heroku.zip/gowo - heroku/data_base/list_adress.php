<?php
    require_once('db.class.php');

    $id_usr = $_SESSION['id_usr'];
    $active_adress = $_SESSION['active_adress'];

    $objDb = new db();
    $link = $objDb->mysql_connect();
    $sql = "SELECT * FROM adressusers WHERE id_user = '$id_usr' AND id = $active_adress";

    $result_id = mysqli_query($link, $sql);

    if($result_id){
        $user_data = mysqli_fetch_array($result_id);

        $_SESSION['adress'] = $user_data['adress'];
        $_SESSION['cep'] = $user_data['cep'];
        $_SESSION['number'] = $user_data['number'];
        $_SESSION['nbh'] = $user_data['nbh'];
        $_SESSION['city'] = $user_data['city'];
        $_SESSION['state'] = $user_data['state'];
        $_SESSION['complement'] = $user_data['complement'];

    }else{
        echo"Erro ao entrar entre em contato com o suporte";
    }

    
?>