<?php
    session_start();
    require_once('db.class.php');

    $cep = $_POST ['cep'];
    $adr = $_POST ['adr'];
    $nmr = $_POST ['nmr'];
    $nbh = $_POST ['nbh'];
    $city = $_POST ['city'];
    $std = $_POST ['state'];
    $comp = $_POST ['complement'];
    $id_usr = $_SESSION['id_usr'];

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $sql = "insert into adressusers(cep, adress, number, nbh, city, id_user, state, complement) values ('$cep', '$adr', '$nmr', '$nbh', '$city', '$id_usr', '$std', '$comp')";

    if(mysqli_query($link,$sql)){
        $objDb = new db();
        $link = $objDb->mysql_connect();

        $sql = "SELECT MAX(id) FROM adressusers WHERE id_user = '$id_usr'";
        var_dump($sql);
        $result_id = mysqli_query($link, $sql);
        $user_data = mysqli_fetch_array($result_id);
        $_SESSION['adress_id'] = $user_data['MAX(id)'];
        $update_id_adress = $user_data['MAX(id)'];
        echo$update_id_adress;
        $sql = "UPDATE users SET active_adress='$update_id_adress' WHERE id = '$id_usr'";
        mysqli_query($link,$sql);
        require_once('list_adress.php');

        header('Location: ../views/store?sucess=1');
    }else{
        echo 'Código de erro:'.mysqli_errno( $link ).'<br>';
        echo 'Mensagem de erro:'.mysqli_error( $link ).'<br>';
    }

?>