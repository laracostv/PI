<?php

    require_once('db.class.php');
    include_once('db.class.php');

    $name = $_POST ['first-name'];
    $last_name = $_POST ['last-name'];
    $email = $_POST ['email'];
    $senha = md5($_POST ['pwd']);
    $cellNumber = $_POST ['number'];
    $dateN = $_POST ['date'];
    $existent_email = false;

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $sql = " select * from users where email ='$email'";

    if($id_result = mysqli_query($link, $sql)){
        $data_ver_usr = mysqli_fetch_array($id_result);

        if(isset($data_ver_usr['email'])){
            $existent_email = true;
        }
    }else{
        echo 'Erro ao tentar autenticar dados';
    };

    if($existent_email){
        $get_return = '?email_exist=1&';
        header('Location: ../views/inicial/cadastro.php'.$get_return);
        die();
    }

        $arquivo = $_FILES['arquivo']['name'];
			
			//Pasta onde o arquivo vai ser salvo
			$_UP['pasta'] = '../assets/images/all-images/profile_photos/';
			
			//Tamanho máximo do arquivo em Bytes
			$_UP['tamanho'] = 1024*1024*100; //5mb
			
			//Array com a extensões permitidas
			$_UP['extensoes'] = array('png', 'jpg', 'jpeg', 'gif');
			
			//Renomeiar
			$_UP['renomeia'] = true;
			
			//Array com os tipos de erros de upload do PHP
			$_UP['erros'][0] = 'Não houve erro';
			$_UP['erros'][1] = 'O arquivo no upload é maior que o limite do PHP';
			$_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especificado no HTML';
			$_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente';
			$_UP['erros'][4] = 'Não foi feito o upload do arquivo';
			
			//Verifica se houve algum erro com o upload. Sem sim, exibe a mensagem do erro
			if($_FILES['arquivo']['error'] != 0){
				die("Não foi possivel fazer o upload, erro: <br />". $_UP['erros'][$_FILES['arquivo']['error']]);
				exit; //Para a execução do script
			}
			
			//Faz a verificação da extensao do arquivo
            $tmp_format = explode('.', $_FILES['arquivo']['name']);
			$extensao = strtolower(end($tmp_format));
			if(array_search($extensao, $_UP['extensoes']) === false){		
				echo "
					<script type=\"text/javascript\">
						alert(\"A imagem não foi cadastrada extensão inválida.\");
					</script>
				";
			}
			
			//Faz a verificação do tamanho do arquivo
			else if ($_UP['tamanho'] < $_FILES['arquivo']['size']){
				echo "
					<script type=\"text/javascript\">
						alert(\"Arquivo muito grande.\");
					</script>
				";
			}
			
			//O arquivo passou em todas as verificações, hora de tentar move-lo para a pasta foto
			else{
				//Primeiro verifica se deve trocar o nome do arquivo
				if($_UP['renomeia'] == true){
					//Cria um nome baseado no UNIX TIMESTAMP atual e com extensão .jpg
                    $nome_final = md5(time()).'.jpg';
                    
				}else{
					//mantem o nome original do arquivo
					$nome_final = $_FILES['arquivo']['name'];
				}
				//Verificar se é possivel mover o arquivo para a pasta escolhida
				if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'].$nome_final)){
                    //Upload efetuado com sucesso, exibe a mensagem
                    $blank_var = true;
				}else{
					//Upload não efetuado com sucesso, exibe a mensagem
					echo "
						<script type=\"text/javascript\">
							alert(\"Imagem não foi cadastrada com Sucesso.\");
                        </script>
                    ";
                    die();
				}
			}


    $sql = "insert into users(name, last_name, email, pwd, cellPhone, dateN, active_adress, profile_photo) values ('$name', '$last_name', '$email', '$senha', '$cellNumber', '$dateN', '0', '$nome_final')";

    if(mysqli_query($link,  $sql)){
        session_start();
        $sql = "SELECT * FROM users WHERE email = '$email' AND pwd = '$senha'";

        $objDb = new db();
        $link = $objDb->mysql_connect();

        $result_id = mysqli_query($link, $sql);

        if($result_id){
            $user_data = mysqli_fetch_array($result_id);
            if(isset($user_data['email'])){

                $_SESSION['name'] = $user_data['name'];
                $_SESSION['last_name'] = $user_data['last_name'];
                $_SESSION['email'] = $user_data['email'];
                $_SESSION['cell'] = $user_data['cellPhone'];
                $_SESSION['dateN'] = $user_data['dateN'];
                $_SESSION['profile_photo'] = $user_data['profile_photo'];
                $_SESSION['id_usr'] = $user_data['id'];
                $_SESSION['active_adress'] = $user_data['active_adress'];
                
                header('Location: ../views/store?alert=1');
            }else{
                header('Location: ../index.php?erro=1');
            }
        }else{
            echo"Erro ao se conectar: entre em contato com o suporte";
        }
    }else{
        echo'Erro de protocolo';
    };
?>