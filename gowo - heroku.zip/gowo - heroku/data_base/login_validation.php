<?php
    session_start();
    require_once('db.class.php');

    $loginUser = $_POST['user'];
    $pwdUser = md5($_POST['pwd']);

    $sql = "SELECT * FROM users WHERE email = '$loginUser' AND pwd = '$pwdUser'";

    $objDb = new db();
    $link = $objDb->mysql_connect();

    $result_id = mysqli_query($link, $sql);

    if($result_id){
        $user_data = mysqli_fetch_array($result_id);
        if(isset($user_data['email'])){

            $_SESSION['name'] = $user_data['name'];
            $_SESSION['last_name'] = $user_data['last_name'];
            $_SESSION['email'] = $user_data['email'];
            $_SESSION['cell'] = $user_data['cellPhone'];
            $_SESSION['dateN'] = $user_data['dateN'];
            $_SESSION['profile_photo'] = $user_data['profile_photo'];
            $_SESSION['id_usr'] = $user_data['id'];
            $_SESSION['active_adress'] = $user_data['active_adress'];           

            header('Location: ../views/store');
        }else{
            header('Location: ../index.php?erro=1');
        }
    }else{
        echo"Login error: entre em contato com o suporte";
    }

    
?>