<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../assets/icons/favicon-512x512.png" type="image/x-png">
    <link rel="apple-touch-icon" sizes="180x180" href="../../assets/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../assets/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/icons/favicon-16x16.png">
    <link rel="manifest" href="../../assets/icons/site.webmanifest">
    <link rel="mask-icon" href="../../assets/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../public/css/views-style/chat.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/material_design.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../public/script/chat.js"></script>
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Alata&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide, ame e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>

<div class="navigation-bar hidden-md hidden-lg">
     <img src="../../assets/images/logos/gowo-simbolo.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png" onclick="navRed(1)">   
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false" onclick="navRed(1)">
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item" onclick="navRed(1)">Início</div>
                <div class="nav-item active-item" onclick="navRed(2)">Chat</div>
                <div class="nav-item" onclick="navRed(3)">Recentes</div>
                <div class="nav-item" onclick="navRed(4)">Perfil</div>
        </div>
    </div>
</div>
    <div class="space-chat-top-large hidden-xs hidden-sm"></div>
    <div class="space-chat-top-small hidden-md hidden-lg"></div>
    <!--
    <div class="btn-circle hidden-md hidden-lg"><i data-feather="pen-tool" class="icon-write"></i></div>
    <div class="btn-circle-mdlg hidden-xs hidden-sm"><i data-feather="pen-tool" class="icon-write"></i></div>
    -->
        <div class="container box-general-chat">
            <div class="row">

                <div class="col-md-4 list-chat-colum">

                    <div class="box-chat-search">
                        <div class="input-group">
                            <span class="input-group-addon box-icon">
                            <i data-feather="search" class="bar-icon"></i>
                            </span>
                            <input type="text" id="search-input" placeholder="Procurar contatos ou mensagens" class="input-complete">
                        </div>
                    </div>


                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/0bdd8bd46c23e853f955dd548e903b41.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Confiance Estética Automotiva</div>
                            <div class="chat-list-last-m">Oferecemos também: Limpeza Vip...</div>
                        </div>
                        <div class="box-chat-number">
                            <div class="chat-list-number">3</div>
                        </div>
                    </div>

                    <div class="box-chat chat-active-list">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/84105cda4c7c3c69ff4801b2859e719f.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Cabeça de Ideias</div>
                            <div class="chat-list-last-m">Ok</div>
                        </div>
                        <div class="box-chat-number">
                            
                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/eb4d9edc08280b6e2fc7d59ba5047c1e.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Lorenna Monteil Studio</div>
                            <div class="chat-list-last-m">A Micropigmentação Fio a Fio...</div>
                        </div>
                        <div class="box-chat-number">
                            <div class="chat-list-number">2</div>
                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/4c5d62de8d9484ee7587465a37a99e93.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">CLIMEV</div>
                            <div class="chat-list-last-m">Tosa e banho está saindo por...</div>
                        </div>
                        <div class="box-chat-number">
                            <div class="chat-list-number">5</div>
                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/a8d47da52309cc37cccaf577d8cde33b.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Vertical Jardinagem</div>
                            <div class="chat-list-last-m">Oferecemos também: Limpeza Vip...</div>
                        </div>
                        <div class="box-chat-number">
                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/7069cbadc503deaf19feee4cf262bc37.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Casa do Mecânico</div>
                            <div class="chat-list-last-m">Recebido</div>
                        </div>
                        <div class="box-chat-number">
                            
                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/f413f96b75bdb25ac9b779b4bfb2963d.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">RD Bastos</div>
                            <div class="chat-list-last-m">Entendido, obrigado!</div>
                        </div>
                        <div class="box-chat-number">

                        </div>
                    </div>

                    <div class="box-chat">
                        <div class="box-chat-img">
                            <img class="chat-list-img" src="../../assets/images/all-images/store-profile/41578c06c396b0e9f0ea27b1d5436718.jpg">
                        </div>
                        <div class="box-chat-info">
                            <div class="chat-list-name">Chez Mom</div>
                            <div class="chat-list-last-m">Boa tarde, acabou de sair para entrega</div>
                        </div>
                        <div class="box-chat-number">

                        </div>
                    </div>

                    <div class="space-chat-bottom hidden-md hidden-lg"></div>
                </div>

                <div class="col-md-8 chat-active-total hidden-sm hidden-xs">
                    <div class="chat-active-bar">
                        <img src="../../assets/images/all-images/store-profile/84105cda4c7c3c69ff4801b2859e719f.jpg" class="chat-active-profile-photo">
                        <div class="chat-active-user">Cabeça de Ideias</div>
                    </div>

                    <div class="chat-active-message-area">
                        <div class="spacer-mensage-box-top"></div>

                        <div class="container-message">
                            <div class="recived-mensage">
                                <span>
                                Olá! me chamo Lara, gostaria de mais informações dos serviços disponíveis
                                </span>
                                <div class="recived-message-date-time">22:54</div>
                            </div>
                        </div>

                        <div class="container-message">
                            <div class="user-sed-mensage">
                                Olá Lara, ficamos felizes em ter você aqui!
                                <div class="recived-message-date-time">22:54</div>
                            </div>
                        </div>
                        
                        <div class="recived-mensage">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe atque minus officiis mollitia dolore sapiente consectetur tempore exercitationem fugiat! Velit in porro repellat consequuntur nemo repellendus molestias nobis minus deleniti!
                            <div class="recived-message-date-time">22:54</div>
                        </div>

                        <div class="recived-mensage">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe atque minus officiis mollitia dolore sapiente consectetur tempore exercitationem fugiat! Velit in porro repellat consequuntur nemo repellendus molestias nobis minus deleniti!
                            <div class="recived-message-date-time">22:54</div>
                        </div>

                        <div class="recived-mensage">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe atque minus officiis mollitia dolore sapiente consectetur tempore exercitationem fugiat! Velit in porro repellat consequuntur nemo repellendus molestias nobis minus deleniti!
                            <div class="recived-message-date-time">22:54</div>
                        </div>

                        <div class="recived-mensage">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe atque minus officiis mollitia dolore sapiente consectetur tempore exercitationem fugiat! Velit in porro repellat consequuntur nemo repellendus molestias nobis minus deleniti!
                            <div class="recived-message-date-time">22:54</div>
                        </div>

                        <div class="user-sed-mensage">
                            Teste mensagem
                            <div class="recived-message-date-time">22:54</div>
                        </div>

                        <div class="spacer-mensage-box-bottom"></div>
                    </div>

                    <div class="chat-active-inputs">
                        <textarea rows="1" style="resize: none" oninput='message_input(this)'  placeholder="Digite uma mensagem..." class="chat-active-input-message"></textarea>
                        <div class="send-destaque-circle">
                            <i data-feather="send" class="chat-active-inputs-icon-send"></i>
                        </div>
                        <i data-feather="paperclip" class="chat-active-inputs-icon-right"></i>
                        <i data-feather="smile" class="chat-active-inputs-icon-right"></i>
                    </div>

                </div>


            </div>
        </div>
    <div class="container-fluid navigation-bar-mobile hidden-md hidden-lg">
        <div class="row">
            <div class="col-md-12">

                    <div class="item-nav-mob" onclick="navRed(1)">
                        <i data-feather="home" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Início</div>
                    </div>

                    <div class="item-nav-mob" onclick="navRed(2)">
                        <i data-feather="message-square" class="nav-icon"></i>
                        <div class="text-nav">Chat</div>
                    </div>
                
                    <div class="item-nav-mob" onclick="navRed(3)">
                        <i data-feather="bell" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Recentes</div>
                    </div>                

                    <div class="item-nav-mob" onclick="navRed(4)">
                        <i data-feather="user" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Perfil</div>
                    </div>

            </div>
        </div>
    </div>


<script>
    feather.replace();
</script>
</body>
</html>