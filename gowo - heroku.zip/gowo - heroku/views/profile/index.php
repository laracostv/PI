<?php 
    session_start();
    if(!isset($_SESSION['email'])){
        if(!isset($_SESSION['store_email'])){
            header('Location: ../../index.php?erro=2');
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="apple-touch-icon" sizes="180x180" href="../../assets/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../assets/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/icons/favicon-16x16.png">
    <link rel="manifest" href="../../assets/icons/site.webmanifest">
    <link rel="mask-icon" href="../../assets/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="../../assets/icons/favicon-512x512.png" type="image/x-png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/views-style/profile.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../public/script/nav.js"></script> 
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>

<div class="navigation-bar hidden-md hidden-lg">
     <img src="../../assets/images/logos/gowo-simbolo.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png" onclick="navRed(1)">   
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false" onclick="navRed(1)">
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item" onclick="navRed(1)">Início</div>
                <div class="nav-item" onclick="navRed(2)">Chat</div>
                <div class="nav-item" onclick="navRed(3)">Recentes</div>
                <div class="nav-item active-item" onclick="navRed(4)">Perfil</div>
        </div>
    </div>
</div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>
    
    <div class="container">
        <div class="first-desc">
            <center>
                <div
                style='
                    border-radius: 50%;
                    height: 90px;
                    width: 90px;
                    <?php
                    if(isset($_SESSION['email'])){
                        echo'background-image: url("../../assets/images/all-images/profile_photos/'.$_SESSION['profile_photo'].'");';
                    }
                    if(isset($_SESSION['store_email'])){
                        echo'background-image: url("../../assets/images/all-images/store-profile/'.$_SESSION['store_img'].'");';
                    }
                    ?>
                    background-repeat: no-repeat;
                    background-size: cover;
                '></div>
            </center>
            <div class="user-name-profile">
                <?php
                    if(isset($_SESSION['name'])){
                        echo$_SESSION['name'];
                    }
                    if(isset($_SESSION['store_name'])){
                        echo$_SESSION['store_name'];
                    }
                ?>
            </div>
            <a href="pages/edit_profile"><div class="user-desc">Editar perfil</div></a>
        </div>
        <div class="spacer-photo-bt-box"></div>
        
        <div class="options-profile-menu">
            <a href="pages/suport">
            <div class="box-option">
                <i data-feather="help-circle" class="icon-box"></i>
                <div class="box-desc">
                    <div class='option-title'>Ajuda</div>
                    <!--<div class='option-subtitle'>Reclamações, FAQ e mais</div>-->
                </div>
            </div>
            </a>

            <a href="pages/config">
            <div class="box-option">
                <i data-feather="settings" class="icon-box"></i>
                <div class="box-desc">
                    <div class='option-title'>Configurações</div>
                    <!--<div class='option-subtitle'>Perfil, </div>-->
                </div>
            </div>
            </a>

            <a href="pages/orders">
            <div class="box-option">
                <i data-feather="book" class="icon-box"></i>
                <div class="box-desc">
                    <div class='option-title'>Histórico de pedidos</div>
                    <!--<div class='option-subtitle'>Perfil, </div>-->
                </div>
            </div>
            </a>
        </div>
        <a href="../../data_base/exit_session.php"><div class="exit-text">Sair</div></a>
    </div>


       <div class="space-bottom"></div>
       <div class="container-fluid navigation-bar-mobile hidden-md hidden-lg">
        <div class="row">
            <div class="col-md-12">

                    <div class="item-nav-mob" onclick="navRed(1)">
                        <i data-feather="home" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Início</div>
                    </div>

                    <div class="item-nav-mob" onclick="navRed(2)">
                        <i data-feather="message-square" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Chat</div>
                    </div>
                
                    <div class="item-nav-mob" onclick="navRed(3)">
                        <i data-feather="bell" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Recentes</div>
                    </div>                

                    <div class="item-nav-mob" onclick="navRed(4)">
                        <i data-feather="user" class="nav-icon"></i>
                        <div class="text-nav">Perfil</div>
                    </div>

            </div>
        </div>
    </div>


<script>
    feather.replace();
</script>
</body>
</html>