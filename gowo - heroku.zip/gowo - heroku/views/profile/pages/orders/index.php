<?php 
    session_start();
    if(!isset($_SESSION['email'])){
        header('Location: ../../index.php?erro=2');
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../../../assets/images/favicon.png" type="image/x-png">
    <link href="../../../../assets/images/logos/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180"/>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/views-style/profile.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../../../public/script/usual/suport.js"></script> 
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>

<div class="navigation-bar hidden-md hidden-lg">
    <img src="../../../../assets/images/logos/logo-gowo-h120.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png" onclick="navRedThird(1)">
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <img src="../../../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false" onclick="navRedThird(1)">
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item" onclick="navRedThird(1)">Início</div>
                <div class="nav-item" onclick="navRedThird(2)">Buscar</div>
                <div class="nav-item" onclick="navRedThird(3)">Recentes</div>
                <div class="nav-item active-item" onclick="navRedThird(4)">Perfil</div>
        </div>
    </div>
</div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>
    
    <div class="container">
        <center>
            <i data-feather="book" class="icon-session"></i>
            <div class="title-session">Histórico de Pedidos</div>
        </center>
        <div class="spacer-photo-bt-box"></div>
        
        <div class="options-profile-menu">


       <div class="space-bottom"></div>

<script>
    feather.replace();
</script>
</body>
</html>