<?php 
    session_start();
    if(!isset($_SESSION['email'])){
        if(!isset($_SESSION['store_email'])){
            header('Location: ../../index.php?erro=2');
        }
    }

    $protocol = isset($_GET['protocol']) ? $_GET['protocol'] : 0;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../../../assets/images/favicon.png" type="image/x-png">
    <link href="../../../../assets/images/logos/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180"/>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/views-style/profile.css">
    <link rel="stylesheet" type="text/css" href="../../../../public/css/views-style/edit_profile.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../../../public/script/profile_edit.js"></script>
    <script type="text/javascript" src="../../../../public/script/jquery.mask.js"></script>
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
    <!--SWEET ALERT-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body>
<?php
    if($protocol == 1){
        echo"<script>
                $(document).ready(function(){
                    confirmMessage()
                    });
                </script>";
    }
    if($protocol == 2){
        echo"<script>
                $(document).ready(function(){
                    errorMessage()
                    });
                </script>";
    }
    ?>

<div class="navigation-bar hidden-md hidden-lg">
    <img src="../../../../assets/images/logos/logo-gowo-h120.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png" onclick="navRedThird(1)">
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <img src="../../../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false" onclick="navRedThird(1)">
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item" onclick="navRedThird(1)">Inicio</div>
                <div class="nav-item" onclick="navRedThird(2)">Buscar</div>
                <div class="nav-item" onclick="navRedThird(3)">Recentes</div>
                <div class="nav-item active-item" onclick="navRedThird(4)">Perfil</div>
        </div>
    </div>
</div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>
    
    <div class="container">
        <div class="first-desc">
        <center>
                <div
                style='
                    border-radius: 50%;
                    height: 90px;
                    width: 90px;
                    <?php
                    if(isset($_SESSION['email'])){
                        echo'background-image: url("../../../../assets/images/all-images/profile_photos/'.$_SESSION['profile_photo'].'");';
                    }
                    if(isset($_SESSION['store_email'])){
                        echo'background-image: url("../../../../assets/images/all-images/store-profile/'.$_SESSION['store_img'].'");';
                    }
                    ?>
                    background-repeat: no-repeat;
                    background-size: cover;
                '></div>
            </center>
            <div class="user-name-profile">
                <?php
                    if(isset($_SESSION['name'])){
                        echo$_SESSION['name'];
                    }
                    if(isset($_SESSION['store_name'])){
                        echo$_SESSION['store_name'];
                    }
                ?>
            </div>
        </div>
        <div class="spacer-photo-bt-box"></div>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
            <form id="update-data-profile" method="POST" action="../../../../data_base/update_data_profile.php">
                <input type="text" id="name" name="name" placeholder="Nome" value="<?= $_SESSION['name']?>" readonly="true">
                <input type="text" id="last-name" name="last_name" placeholder="Sobrenome" value="<?= $_SESSION['last_name']?>" readonly="true" required>
                <input type="email" id="userEmail" name="email" placeholder="exemplo@email.com" value="<?= $_SESSION['email']?>" readonly="true" required>
                <input type="text" id="dateN" name="dateN" placeholder="XX/XX/XXXX" value="<?= $_SESSION['dateN']?>" readonly="true" require>
                <input type="text" id="cel" name="cell" placeholder="(xx) xxxxx-xxxx" value="<?= $_SESSION['cell']?>" readonly="true" required>
                <input type="password" id="pasw" name="pwd" placeholder="Senha" readonly="true" required>
                <center><input type="button" value="Editar" name="submit" class="but" id="btn-edit"></center>
                <center><input type="submit" value="Confirmar Alterações" name="submit" class="but" id="btn-send"></center>
            </form>
            </div>
        </div>
    </div>


<script>
    feather.replace();
</script>
</body>
</html>