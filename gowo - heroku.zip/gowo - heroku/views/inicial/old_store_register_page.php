<?php
    $email_exist = isset($_GET['email_exist']) ? $_GET['email_exist'] : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="../../assets/images/favicon.png" type="image/x-png">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
  <link rel="stylesheet" type="text/css" href="../../public/css/index.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="../../public/script/jquery.mask.js"></script>
  <script type="text/javascript" src="../../public/script/index.js"></script>  
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body id="fundo"> 

  <center>
    <a href="../../index.php">
      <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false">
    </a>
  </center>
  <div class="container">
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
      <center>
        <div class="title-days" style="font-size: 26px">Cadastrar Estabelecimento</div>
      </center>
        <center>
            <form method="POST" action="../../data_base/store_register.php" class="form-back" enctype="multipart/form-data">
                <div class="fileUpload"><input type="file" name="arquivo" id="up_image" class="upload" required/></div>
                <input type="text" name="store_name" placeholder="Nome do estabelecimento" maxlength="100" required>
                <select id="store_class" name="store_class" required>
                    <option value="gowo Shop ">Escolha a categoria</option>
                    <option value="Automotivo">Automotivo</option>
                    <option value="Beleza">Beleza</option>
                    <option value="Comida">Comida</option>
                    <option value="Corte e Costura">Corte e Costura</option>
                    <option value="Cuidados gowo">Cuidados gowo</option>
                    <option value="Design">Design</option>
                    <option value="Fotografia">Fotografia</option>
                    <option value="Informática">Informática</option>
                    <option value="Jardinagem">Jardinagem</option>
                    <option value="Limpeza">Limpeza</option>
                    <option value="Reformas e Consertos">Reformas e Consertos</option>
                </select>
                <input type="email" name="store_email" placeholder="Email" required="@">
                <input type="password" maxlength="32" name="store_pwd" placeholder="Senha" required>
                <input type="tel" id="cel" name="store_tel" placeholder="Celular" onkeypress="return onlyNumbers(event)" required>
              <button type="submit" class="but">Cadastrar</button>
            </form>
            
            <br>
            <br>
          </div>
        </center>
      </div>   
    </div>

</div>
<?php
                if($email_exist == 1){
                  echo"<script>
                  $(document).ready(function(){
                      alertMenssageCad()
                    });
                  </script>";
                }
              ?>
</body>
</html>