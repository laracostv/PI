<?php
    $email_exist = isset($_GET['email_exist']) ? $_GET['email_exist'] : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
  <!--meta tags index-->
  <meta property="og:locale" content="pt_BR">
  <meta property="og:url" content="https://gowoifes.herokuapp.com/">
  <meta property="og:title" content="GoWo">
  <meta property="og:site_name" content="Gowo">
  <meta property="og:description" content="">
  <meta property="og:image" content="https://gowoifes.herokuapp.com/assets/icons/apple-touch-icon.png">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="260">
  <meta property="og:image:height" content="260">
  <meta property="og:type" content="website">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  <!--FAVICONS-->
  <link rel="shortcut icon" href="../../assets/icons/favicon-512x512.png" type="image/x-png">
  <link rel="apple-touch-icon" sizes="180x180" href="../../assets/icons/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../../assets/icons/favicon-16x16.png">
  <link rel="manifest" href="../../assets/icons/site.webmanifest">
  <link rel="mask-icon" href="../../assets/icons/safari-pinned-tab.svg" color="#ffffff">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="theme-color" content="#ffffff">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
  <link rel="stylesheet" type="text/css" href="../../public/css/newindex.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="../../public/script/jquery.mask.js"></script>
  <script type="text/javascript" src="../../public/script/index.js"></script>  
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body id="fundo"> 

  <center>
    <a href="../../index.php">
      <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false">
    </a>
  </center>
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-md-3"></div>
      <div class="col-md-8 col-lg-6">
        <center>
            <form method="POST" action="../../data_base/store_register.php" class="form-back" enctype="multipart/form-data">
                <div class="title-days" style="font-size: 26px">Cadastrar Estabelecimento</div>
                <div class="fileUpload"><input type="file" name="arquivo" id="up_image" class="upload" required/></div>
                <div class="input-container">
                    <input id="store_name" name="store_name" class="input" type="text" maxlength="100" placeholder="Nome do estabelecimento" required />
                    <label class="label" for="store_name">Nome do estabelecimento</label>
                </div>
                <div class="input-container">
                <select id="store_class" name="store_class" class="input" required>
                    <option value="gowo Shop ">Escolha a categoria</option>
                    <option value="Automotivo">Automotivo</option>
                    <option value="Beleza">Beleza</option>
                    <option value="Comida">Comida</option>
                    <option value="Corte e Costura">Corte e Costura</option>
                    <option value="Cuidados gowo">Cuidados Pet</option>
                    <option value="Design">Design</option>
                    <option value="Fotografia">Fotografia</option>
                    <option value="Informática">Informática</option>
                    <option value="Jardinagem">Jardinagem</option>
                    <option value="Limpeza">Limpeza</option>
                    <option value="Reformas e Consertos">Reformas e Consertos</option>
                </select>
                </div>
                <div class="input-container">
                    <input id="store_email" name="store_email" class="input" type="email" maxlength="100" placeholder="exemplo@email.com" required="@" />
                    <label class="label" for="store_email">Email</label>
                </div>
                <div class="input-container">
                    <input id="store_pwd" maxlength="32" name="store_pwd" class="input" type="password" placeholder="*****" required />
                    <label class="label" for="store_pwd">Senha</label>
                </div>
                <div class="input-container">
                    <input id="cel" name="store_tel" class="input" type="tel" maxlength="14" onkeypress="return onlyNumbers(event)" placeholder="(XX) XXXXX-XXXX" required />
                    <label class="label" for="cel">Celular</label>
                </div>
              <button type="submit" class="but">Cadastrar</button>
            </form>
            
            <br>
            <br>
          </div>
        </center>
      </div>   
    </div>

</div>
<?php
                if($email_exist == 1){
                  echo"<script>
                  $(document).ready(function(){
                      alertMenssageCad()
                    });
                  </script>";
                }
              ?>
</body>
</html>