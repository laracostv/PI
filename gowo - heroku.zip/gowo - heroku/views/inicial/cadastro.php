<?php
    $email_exist = isset($_GET['email_exist']) ? $_GET['email_exist'] : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
    <!--meta tags index-->
  <meta property="og:locale" content="pt_BR">
  <meta property="og:url" content="https://gowoifes.herokuapp.com/">
  <meta property="og:title" content="GoWo">
  <meta property="og:site_name" content="Gowo">
  <meta property="og:description" content="">
  <meta property="og:image" content="https://gowoifes.herokuapp.com/assets/icons/apple-touch-icon.png">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="260">
  <meta property="og:image:height" content="260">
  <meta property="og:type" content="website">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  <link rel="shortcut icon" href="../../assets/images/favicon.png" type="image/x-png">
  <!--FAVICONS-->
  <link rel="shortcut icon" href="../../assets/icons/favicon-512x512.png" type="image/x-png">
  <link rel="apple-touch-icon" sizes="180x180" href="../../assets/icons/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../../assets/icons/favicon-16x16.png">
  <link rel="manifest" href="../../assets/icons/site.webmanifest">
  <link rel="mask-icon" href="../../assets/icons/safari-pinned-tab.svg" color="#ffffff">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="theme-color" content="#ffffff">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
  <link rel="stylesheet" type="text/css" href="../../public/css/newindex.css">
  <link rel="stylesheet" type="text/css" href="../../public/css/cadastro.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="../../public/script/jquery.mask.js"></script>
  <script type="text/javascript" src="../../public/script/index.js"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
  <script type="text/javascript" src="../../public/script/cadastro.js"></script>
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body id="imgFundo"> 

  <?php
    
  ?>


  <center>
    <br>
    <a href="../../index.php">
      <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false">
    </a>
  </center>
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-lg-3"></div>
      <div class="col-md-8 col-lg-6">
      <div class="box-cad">
            <form method="POST" action="../../data_base/user_register.php" enctype="multipart/form-data">
                <center>
                <div class="fileUpload"><input type="file" name="arquivo" id="up_image" class="upload" required/></div>
                </center>
                <div class="input-container">
                    <input id="first-name" name="first-name" class="input" type="text" pattern=".+" placeholder="Nome" required />
                    <label class="label" for="first-name">Nome</label>
                </div>
                <div class="input-container">
                    <input id="last-name" name="last-name" class="input" type="text" pattern=".+" placeholder="Sobrenome" required />
                    <label class="label" for="last-name">Sobrenome</label>
                </div>
                <div class="input-container">
                    <input id="email" name="email" class="input" type="email" placeholder="exemplo@email.com" required="@" />
                    <label class="label" for="email">Email</label>
                </div>
                <div class="input-container">
                    <input id="pwd" name="pwd" class="input" onkeyup="pwd_check()" onfocus="open_req()" type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" placeholder="*****" required />
                    <label class="label" for="pwd">Senha</label>
                    <div class="pwd-req">
                      <ul>
                        <li id="check1"><i id="icon1" data-feather="x" class="pwd-req-icon"></i><i id="checkIcon1" data-feather="check" class="pwd-req-icon"></i>6 ou mais caracteres</li>
                        <li id="check2"><i id="icon2" data-feather="x" class="pwd-req-icon"></i><i id="checkIcon2" data-feather="check" class="pwd-req-icon"></i>Letras maiúsculas e minúsculas</li>
                        <li id="check3"><i id="icon3" data-feather="x" class="pwd-req-icon"></i><i id="checkIcon3" data-feather="check" class="pwd-req-icon"></i>Pelo menos um número</li>
                      </ul>
                    </div>
                </div>
                <div class="input-container">
                    <input id="cel" name="number" class="input" type="tel" onkeypress="return onlyNumbers(event)" placeholder="(XX) XXXXX-XXXX" required/>
                    <label class="label" for="cel">Celular</label>
                </div>
                <div class="input-container">
                    <input id="dateN" name="date" class="input" type="tel" onkeypress="return onlyNumbers(event)" placeholder="dd/mm/aaaa" required/>
                    <label class="label" for="dateN">Data de Nascimento</label>
                </div>
                <!--
              <input type="text" name="first-name" placeholder="Nome" required>
              <input type="text" name="last-name" placeholder="Sobrenome" required>
              <input type="email" name="email" placeholder="Email" required="@">
              <input type="password" maxlength="32" name="pwd" placeholder="Senha" required>
              <input type="tel" id="cel" name="number" placeholder="Celular" onkeypress="return onlyNumbers(event)" required>
              <input type="tel" id="dateN" name="date" placeholder="DD/MM/AAAA" onkeypress="return onlyNumbers(event)" required>
              -->
              <center><button type="submit" class="but">Cadastrar</button></center>
            </form>
        </div>
            <div class="spacer-120px"></div>
          </div>
      </div>   
    </div>
</div>
<?php
                if($email_exist == 1){
                  echo"<script>
                  $(document).ready(function(){
                      alertMenssageCad()
                    });
                  </script>";
                }
              ?>
<script>
    feather.replace();
</script>
</body>
</html>