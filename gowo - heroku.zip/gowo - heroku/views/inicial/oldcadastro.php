<?php
    $email_exist = isset($_GET['email_exist']) ? $_GET['email_exist'] : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="../../assets/images/favicon.png" type="image/x-png">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
  <link rel="stylesheet" type="text/css" href="../../public/css/index.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="../../public/script/jquery.mask.js"></script>
  <script type="text/javascript" src="../../public/script/index.js"></script>  
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body id="imgFundo"> 

  <?php
    
  ?>

<div class="imgFundo">
  <center>
    <a href="../../index.php">
      <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false">
    </a>
  </center>
  <div class="container">
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <center>
            <form method="POST" action="../../data_base/user_register.php" enctype="multipart/form-data">
              <div class="fileUpload"><input type="file" name="arquivo" id="up_image" class="upload" required/></div>
              <input type="text" name="first-name" placeholder="Nome" required>
              <input type="text" name="last-name" placeholder="Sobrenome" required>
              <input type="email" name="email" placeholder="Email" required="@">
              <input type="password" maxlength="32" name="pwd" placeholder="Senha" required>
              <input type="tel" id="cel" name="number" placeholder="Celular" onkeypress="return onlyNumbers(event)" required>
              <input type="tel" id="dateN" name="date" placeholder="DD/MM/AAAA" onkeypress="return onlyNumbers(event)" required>
              <button type="submit" class="but">Cadastrar</button>
            </form>
          </div>
        </center>
      </div>   
    </div>
</div>
</div>
<?php
                if($email_exist == 1){
                  echo"<script>
                  $(document).ready(function(){
                      alertMenssageCad()
                    });
                  </script>";
                }
              ?>
</body>
</html>