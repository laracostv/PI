<?php 
    session_start();
    if(!isset($_SESSION['email'])){
        if(!isset($_SESSION['store_email'])){
            header('Location: ../../index.php?erro=2');
        }
    }
    
    $protocol = isset($_GET['sucess']) ? $_GET['sucess'] : 0;
    $alert = isset($_GET['alert']) ? $_GET['alert'] : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../assets/icons/favicon-512x512.png" type="image/x-png">
    <link rel="apple-touch-icon" sizes="180x180" href="../../assets/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../../assets/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/icons/favicon-16x16.png">
    <link rel="manifest" href="../../assets/icons/site.webmanifest">
    <link rel="mask-icon" href="../../assets/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../public/css/views-style/store.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../public/script/store.js"></script>
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Anton|Bebas+Neue&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alata&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
    <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
</head>
<body>
<?php
if($protocol == 1){
    echo"<script>
              $(document).ready(function(){
                confirmMessage()
                });
              </script>";
}  
?>
    <div class="navigation-bar hidden-md hidden-lg">
    <i data-feather="chevron-left" id="return-chevron" class="return-chevron" onclick="returnMain(1)"></i>
     <img src="../../assets/images/logos/gowo-simbolo.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png" onclick="navRed(1)">   
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <img src="../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false" onclick="navRed(1)">
            <div class="navigation-items" id="navigation-items">
            <div class="nav-item active-item" onclick="navRed(1)">Início</div>
                <div class="nav-item" onclick="navRed(2)">Chat</div>
                <div class="nav-item" onclick="navRed(3)">Recentes</div>
                <div class="nav-item" onclick="navRed(4)">Perfil</div>
            </div>
        </div>
        <div class="icon-navbar" onclick="redirect(2)"><i data-feather="briefcase"  class='cart-icon-up'></i><div class="number-notification" id='cart-counter'>3</div></div>
    </div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>

    <!--ADRESS VIEW-->
    <div class="container" id="all-adress">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="set-text">ENDEREÇOS</div>

                <?php
                include_once('../../data_base/list_all_adress.php');
                ?>
                                    
                <div class="adress-select" id="add-local" onclick="redirect(1)">
                    <i data-feather="plus-circle" class="local-icon"></i>
                    <div class="adress-description">
                        <div class="adress-title">
                            Adicionar local
                        </div>
                    </div>
                </div>
                <div class="space-bottom"></div>
            </div>
        </div>
    </div>

<div id="all-page">
    <div class="container">
        <div class="row">
        <div class="col-md-2"></div>
            <div class="col-md-8">
            <?php
                if(isset($_SESSION['email'])){
                    include_once('../../data_base/list_adress.php');
                    echo'<div class="adress-box" id="adress-box"><div class="adress-bar" onclick="adressFunction()">'.'
                        <input type="text" placeholder="'.$_SESSION['adress'].', '.$_SESSION['number'].'"
                        disabled="true" class="adr">
                        <i data-feather="chevron-down" class="icon-chevron"></i>
                    </div>
                    <i data-feather="filter" class="store-apoint"></i>
                </div>';
                }
            ?>
                <div class="input-group">
                    <span class="input-group-addon box-icon">
                    <i data-feather="search" class="bar-icon"></i>
                    </span>
                    <input type="text" id="search-input" placeholder="Estabelecimento, produto, serviço..." class="input-complete" onfocus="search()">
                
                </div>

            </div>
        </div>
    </div>

    <div id="allContent">
        <div class="container">

        <div class="row slide-category">
            <div class="col-md-2"></div>
            <div class="col-md-8 distribute-category">

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <center>
                            <div class="category-circle">
                                <i class="fas fa-broom"></i>
                            </div>
                        </center>
                        <div class="category-title">Limpeza</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-tshirt"></i>
                        </div>
                        <div class="category-title">Corte e Costura</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-car"></i>
                        </div>
                        <div class="category-title">Automotivo</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                        <i class="fas fa-heart"></i>
                        </div>
                        <div class="category-title">Beleza</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-paw"></i>
                        </div>
                        <div class="category-title">Cuidados Pet</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-camera"></i>
                        </div>
                        <div class="category-title">Fotografia</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-utensils"></i>
                        </div>
                        <div class="category-title">Comida</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-laptop"></i>
                        </div>
                        <div class="category-title">Informática</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <div class="category-title">Jardinagem</div>
                    </div>
                </div>

                <div class='middle-col-alig'>
                    <div class="category-square">
                        <div class="category-circle">
                            <i class="fas fa-paint-roller"></i>
                        </div>
                        <div class="category-title">Reformas e Consertos</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">

            <?php
                include_once('../../data_base/list_stores.php');
            ?>

            </div>
        </div>
    </div>

    <div class="space-bottom hidden-xs hidden-sm"></div>
    <div class="space-bottom-mob-store hidden-md hidden-lg"></div>
    <div class="bar-cart hidden-md hidden-lg" id="bar-cart" onclick="redirect(2)">
        <div class="cart-box">
            <i data-feather="briefcase"  class='icon-cart'></i>
            <div class="counter-cart-mob">1</div>
        </div>
        <center><div class='text-cart'>Ver Lista</div></center>
        <div class='cart-price'>R$ 185,93</div>
    </div>
    <div class="container-fluid navigation-bar-mobile hidden-md hidden-lg">
        <div class="row">
            <div class="col-md-12">

                    <div class="item-nav-mob" onclick="navRed(1)">
                        <i data-feather="home" class="nav-icon"></i>
                        <div class="text-nav">Início</div>
                    </div>

                    <div class="item-nav-mob" onclick="navRed(2)">
                        <i data-feather="message-square" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Chat</div>
                    </div>
                
                    <div class="item-nav-mob" onclick="navRed(3)">
                        <i data-feather="bell" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Recentes</div>
                    </div>                

                    <div class="item-nav-mob" onclick="navRed(4)">
                        <i data-feather="user" class="nav-icon-gray"></i>
                        <div class="text-nav-gray">Perfil</div>
                    </div>

            </div>
        </div>
    </div>
</div> <!--ALL PAGE HIDE BOX-->


<script>
    feather.replace();
</script>
<?php
        if($alert == 1){
            echo'<script>addFistLocal()</script>';
        }
?>
</body>
</html>