<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../../assets/images/favicon.png" type="image/x-png">
    <link href="../../../assets/images/logos/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180"/>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../../public/css/views-style/store.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/material_design.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../../public/script/local.js"></script>
    <script type="text/javascript" src="../../../public/script/jquery.mask.js"></script>    
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <!--SWEET ALERT-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="../gowo.app">
    <meta property="og:title" content="gowo: cuide, ame e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="O gowo é para aqueles que amam animais e querem demonstrar seu cuidado com eles das mais diversas formas, de forma rápida e simplificada.">
    <meta property="og:image" content="../gowo.app">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>
    <div class="navigation-bar">
        <a href="../../store">
            <img src="../../../assets/images/logos/logo-gowo-h120.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png">
        </a>
    </div>
    <div class="space-top"></div>
<div id="cep-input">
    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="set-text">ADICIONAR NOVO ENDEREÇO</div>
                <br>
                <form method="POST" action="../../../data_base/add_local.php"> 
                    <div class="form">
                        <div class="form-group" id="cep-group">
                            <label for="cep" class="label-text">CEP*:</label>
                            <input id="txtCep" name="cep" type="tel" class="input-set" maxlength="9" placeholder="00000-000" onkeyup="callFunctionCep()">
                            <img src="../../../assets/images/all-images/loader.gif" id="loader" class="loader" draggable="false">
                            <div class="invalid-feedback" id="incorret-cep">
                                Este CEP é inválido ou inexistente.
                            </div>
                        </div>
                    

                    <div id="complete-local">
                        <div id="cep-searched">
                                <div class="form-group">
                                    <label for="cep-s" class="label-text">CEP*:</label>
                                    <input id="cep-s" name="cep-s" type="tel" class="input-set" maxlength="9" placeholder="00000-000" onkeyup="callFunctionCep()">
                                    <img src="../../../assets/images/all-images/loader.gif" id="loader" class="loader" draggable="false">
                                    <div class="invalid-feedback" id="incorret-cep">
                                        Este CEP é inválido ou inexistente.
                                    </div>
                                </div>
                        </div>

                                <div class="form-group">
                                    <label for="end" class="label-text">Endereço*:</label>
                                    <input id="end"  name="adr" type="text" class="input-set" placeholder="Rua, avenida...">
                                </div>

                                <div class="form-group">
                                    <label for="nmr" class="label-text">Número*:</label>
                                    <input id="nmr" name="nmr" type="tel" class="input-set" placeholder="ex.: 123" pattern="[0-9]+$" onkeypress="return onlyNumbers(event)">
                                </div>

                                <div class="form-group">
                                    <label for="bairro" class="label-text">Bairro*:</label>
                                    <input id="bairro" name="nbh" type="text" class="input-set" placeholder="Bairro">
                                </div>

                                <div class="form-group">
                                    <label for="city" class="label-text">Cidade*:</label>
                                    <input id="city" name="city" type="text" class="input-set" placeholder="Cidade">
                                </div>

                            <div class="form-group">
                                <label for="estado" class="label-text">Estado*:</label>
                                <i data-feather="chevron-down" class="selectbox-icon"></i>
                                <select class="input-set" name="state" id="estado" onchange="allCompleted()">
                                    <option value="N">Selecione</option>
                                    <option value="AC">Acre</option>
                                    <option value="AL">Alagoas</option>
                                    <option value="AP">Amapá</option>
                                    <option value="AM">Amazonas</option>
                                    <option value="BA">Bahia</option>
                                    <option value="CE">Ceará</option>
                                    <option value="DF">Distrito Federal</option>
                                    <option value="ES">Espírito Santo</option>
                                    <option value="GO">Goiás</option>
                                    <option value="MA">Maranhão</option>
                                    <option value="MT">Mato Grosso</option>
                                    <option value="MS">Mato Grosso do Sul</option>
                                    <option value="MG">Minas Gerais</option>
                                    <option value="PA">Pará</option>
                                    <option value="PB">Paraíba</option>
                                    <option value="PR">Paraná</option>
                                    <option value="PE">Pernambuco</option>
                                    <option value="PI">Piauí</option>
                                    <option value="RJ">Rio de Janeiro</option>
                                    <option value="RN">Rio Grande do Norte</option>
                                    <option value="RS">Rio Grande do Sul</option>
                                    <option value="RO">Rondônia</option>
                                    <option value="RR">Roraima</option>
                                    <option value="SC">Santa Catarina</option>
                                    <option value="SP">São Paulo</option>
                                    <option value="SE">Sergipe</option>
                                    <option value="TO">Tocantins</option>
                                </select>

                            </div>

                                <div class="form-group">
                                    <label for="complemento" class="label-text">Complemento:</label>
                                    <input id="complemento" name="complement" type="text" class="input-set" placeholder="ex.: Bloco B, Casa A, apt.: 501">
                                </div>
                                <div class="obrigat">* Preenchimento obrigatório</div>

                            <center>
                                <br><br>
                                <button type="submit" class="button-send" id='btn-save' disabled="true">SALVAR</button>
                            </center>
                        </div>
            </form>
        </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
</div>
<!--
    <div class="container">
        <div id="complete-local">
                    <div class="row" id="cep-searched" >
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="cep-s" class="label-text">CEP*:</label>
                                <input id="cep-s" type="tel" class="input-set" maxlength="9" placeholder="00000-000" onkeyup="callFunctionCep()">
                                <img src="../../../assets/images/all-images/loader.gif" id="loader" class="loader" draggable="false">
                                <div class="invalid-feedback" id="incorret-cep">
                                    Este CEP é inválido ou inexistente.
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="end" class="label-text">Endereço*:</label>
                                <input id="end" type="text" class="input-set" placeholder="Rua, avenida...">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="nmr" class="label-text">Número*:</label>
                                <input id="nmr" type="tel" class="input-set" placeholder="ex.: 123" pattern="[0-9]+$" onkeypress="return onlyNumbers(event)">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="bairro" class="label-text">Bairro*:</label>
                                <input id="bairro" type="text" class="input-set" placeholder="Bairro">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="city" class="label-text">Cidade*:</label>
                                <input id="city" type="text" class="input-set" placeholder="Cidade">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                        <div class="form-group">
                            <label for="estado" class="label-text">Estado*:</label>
                            <i data-feather="chevron-down" class="selectbox-icon"></i>
                            <select class="input-set" id="estado" onchange="allCompleted()">
                                <option value="N">Selecione</option>
                                <option value="AC">Acre</option>
                                <option value="AL">Alagoas</option>
                                <option value="AP">Amapá</option>
                                <option value="AM">Amazonas</option>
                                <option value="BA">Bahia</option>
                                <option value="CE">Ceará</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="ES">Espírito Santo</option>
                                <option value="GO">Goiás</option>
                                <option value="MA">Maranhão</option>
                                <option value="MT">Mato Grosso</option>
                                <option value="MS">Mato Grosso do Sul</option>
                                <option value="MG">Minas Gerais</option>
                                <option value="PA">Pará</option>
                                <option value="PB">Paraíba</option>
                                <option value="PR">Paraná</option>
                                <option value="PE">Pernambuco</option>
                                <option value="PI">Piauí</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>
                                <option value="RS">Rio Grande do Sul</option>
                                <option value="RO">Rondônia</option>
                                <option value="RR">Roraima</option>
                                <option value="SC">Santa Catarina</option>
                                <option value="SP">São Paulo</option>
                                <option value="SE">Sergipe</option>
                                <option value="TO">Tocantins</option>
                            </select>

                        </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="complemento" class="label-text">Complemento:</label>
                                <input id="complemento" type="text" class="input-set" placeholder="ex.: Bloco B, Casa A, apt.: 501">
                            </div>
                            <div class="obrigat">* Preenchimento obrigatório</div>
                        </div>
                    </div>

                        <center>
                            <br><br>
                            <button type="submit" class="button-send" id='btn-save' disabled="true" onclick="confirmMessage()">SALVAR</button>
                        </center>

                    </div>
            </div>
        </div>
        </div>-->


    </div>
    <div class="container" id="instructions">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div id="instructions-txt" class="instructions-text" style="cursor: pointer;" onclick="discoverCEP_input()">
                    Não sei meu CEP
                </div>
                <div id='discoverCEP'>
                    <div class="form">
                    <div class="form-group">
                        <label for="estado-c" class="label-text">Estado*:</label>
                            <i data-feather="chevron-down" class="selectbox-icon"></i>
                            <select class="input-set" id="estado-c" onchange="allCompletedSearch()">
                                <option value="N">Selecione</option>
                                <option value="AC">Acre</option>
                                <option value="AL">Alagoas</option>
                                <option value="AP">Amapá</option>
                                <option value="AM">Amazonas</option>
                                <option value="BA">Bahia</option>
                                <option value="CE">Ceará</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="ES">Espírito Santo</option>
                                <option value="GO">Goiás</option>
                                <option value="MA">Maranhão</option>
                                <option value="MT">Mato Grosso</option>
                                <option value="MS">Mato Grosso do Sul</option>
                                <option value="MG">Minas Gerais</option>
                                <option value="PA">Pará</option>
                                <option value="PB">Paraíba</option>
                                <option value="PR">Paraná</option>
                                <option value="PE">Pernambuco</option>
                                <option value="PI">Piauí</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>
                                <option value="RS">Rio Grande do Sul</option>
                                <option value="RO">Rondônia</option>
                                <option value="RR">Roraima</option>
                                <option value="SC">Santa Catarina</option>
                                <option value="SP">São Paulo</option>
                                <option value="SE">Sergipe</option>
                                <option value="TO">Tocantins</option>
                            </select>
                    </div>
                    </div>

                            <div class="form-group">
                                <label for="city-c" class="label-text">Cidade*:</label>
                                <input id="city-c" type="text" class="input-set" placeholder="Cidade">
                            </div>

                            <div class="form-group">
                                <label for="end-c" class="label-text">Endereço*:</label>
                                <input id="end-c" type="text" class="input-set" placeholder="Rua, avenida...">
                            </div>

                        <center>
                            <br>
                            <button type="submit" class="button-send" id='btn-consult' disabled="true" onclick="searchCEP()">Consultar</button>
                        </center>
                        <br>
                        <center>
                            <img src="../../../assets/images/all-images/loader-4.gif" id="point-loader" class="point-loader" draggable="false">
                        </center>
                        <center>
                        <div id="error-mensage-search">
                            <center>
                                <img src="../../../assets/images/all-images/location-loader2.gif" id="error-gif" class="error-gif" draggable="false">
                            </center>
                                <div class="txt-error">NÃO ENCONTREI :(</div>
                                <br>
                                <div class="dsc-error">Mas calma! Aqui estão algumas recomendações para você:</div>
                                <div class="dsc-error">1. Preencheu todos os campos corretamente?</div>
                                <div class="dsc-error">2. O capos estão sem espaços, letras, caracteres sobrando, nada de estranho?</div>
                                <div class="dsc-error">3. Preencha novamente e tenta só pra garantir ;)</div>
                                <div class="dsc-error">4. Recarregue a página</div>
                                <div class="dsc-error">5. Nos mande uma mensagem <a href="../../profile/pages/suport" style="color: #00a39b; font-weight: bold;">aqui</a></div>
                        </div>
                        </center>
                        <div class="results" id="results">
                            <div class="set-text" id="result-text">RESULTADOS ENCONTRADOS</div>
                            <div class="list_results" id="list_results">
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>

    <div class="space-bottom"></div>
    <input type="button" id='myHiddenButtonEnd' visible='false' onclick="javascript:doFocus(1);" width='1px' style="display:none">
    <input type="button" id='myHiddenButtonNmr' visible='false' onclick="javascript:doFocus(2);" width='1px' style="display:none">
<script>
    feather.replace();
</script>
</body>
</html>