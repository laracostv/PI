<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../../assets/images/favicon.png" type="image/x-png">
    <link href="../../../assets/images/logos/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180"/>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/views-style/productmodel.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/views-style/nav-store-model.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../../public/script/model.js"></script>
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Anton|Bebas+Neue&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alata&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide, ame e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>

    <div class="navigation-bar hidden-md hidden-lg">
    <!--
    <i data-feather="chevron-left" id="return-chevron" class="return-chevron" onclick="navRedSecond(2)"></i>
    -->
        <div class="adress-bar">
            <div>
                <a href="../../store">
                    <img src="../../../assets/images/logos/logo-gowo-h120.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png">
                </a>
            </div>
        </div>

    </div>

    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <a href="../../store"><img src="../../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false"></a>
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item active-item" onclick="navRedSecond(1)">Início</div>
                <div class="nav-item" onclick="navRedSecond(2)">Buscar</div>
                <div class="nav-item" onclick="navRedSecond(3)">Recentes</div>
                <div class="nav-item" onclick="navRedSecond(4)">Perfil</div>
            </div>
        </div>
        <div class="icon-navbar" onclick="redirect(3)"><i data-feather="shopping-bag"  class='cart-icon-up'></i><div class="number-notification" id='cart-counter'>3</div></div>
    </div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>

    <div class="container">
    <div class="col-md-3">
        <center>
            <img class="img-product-view" src="../../../assets/images/all-images/product-images/00000001/1.jpg">
        </center>
    </div>
    <div class="col-md-6">
        <div class="title-product">Ração Premier Golden Special Cães Adultos Frango e Carne 20Kg</div>
        <div class="gen-text">Vendido e entregue por <b>Benditogowo</b></div>
        <div class="description-product">
            Ração Premium especial para cães de porte médio em idade adulta,
            músculos fortes: 22% de proteína de alta qualidade, 
            maior rendimento por kg: alimento concentrado e rico em nutrientes,
            naturalmente saudável: sem corantes e aromatizantes artificiais,
            sabor irresistível rico em proteínas de alta qualidade,
            enriquecido com vitaminas e minerais essenciais para maior saúde e vitalidade, 
            intestinos equilibrados: fezes firmes e fáceis de limpar;
        </div>
    </div>
    <div class="col-md-3">
        
        <div class="price-product-view">R$ 135,90</div>
        <div class="text-price-dsc">à vista ou até</div>
        <div>
        <div class="parcels">3x</div><div class="price-parcels">R$ 45,30</div>
        </div>
        <center><div class="add-product-cart-btn">COMPRAR</div></center>
        <center><div class="go-cart-btn">COMPRAR COM UM CLIQUE</div></center>
    </div>
    </div>
    
<script>
    feather.replace();
</script>
</body>
</html>