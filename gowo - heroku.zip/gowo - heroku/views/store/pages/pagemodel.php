<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>GoWo</title>
    <meta charset="utf-8">
    <!--BOOTSTRAP IMPORT-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!--FAVICONS-->
    <link rel="shortcut icon" href="../../../assets/images/favicon.png" type="image/x-png">
    <link href="../../../assets/images/logos/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180"/>
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="../../../public/css/general.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/navigation.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/material_design.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/views-style/page-model.css">
    <link rel="stylesheet" type="text/css" href="../../../public/css/views-style/nav-store-model.css">
    <!--SCRIPTS-->
    <script type="text/javascript" src="../../../public/script/nav.js"></script>
    <script type="text/javascript" src="../../../public/script/model.js"></script>
    <!--ICONS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500|Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp">
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!--FONTS-->
    <link href="https://fonts.googleapis.com/css?family=Anton|Bebas+Neue&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alata&display=swap" rel="stylesheet">
    <!--OPEN GRAPH TAGS-->
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="gowo.app">
    <meta property="og:title" content="gowo: cuide, ame e compartilhe">
    <meta property="og:site_name" content="gowo">
    <meta property="og:description" content="Uma boa descrição">
    <meta property="og:image" content="../../../assets/images/logos/opg-gowo.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800"> <!--PIXELS -->
    <meta property="og:image:height" content="600"> <!-- PIXELS -->
    <meta property="og:type" content="website">
    <meta name="twitter:text:title" content="gowo" />
    <meta name="twitter:card" content="summary" />
</head>
<body>

    <div class="navigation-bar hidden-md hidden-lg">
    <!--
    <i data-feather="chevron-left" id="return-chevron" class="return-chevron" onclick="navRedSecond(2)"></i>
    -->
        <div class="adress-bar">
            <div id="logo-gowo">
                <a href="../../store">
                    <img src="../../../assets/images/logos/logo-gowo-h120.png" class="logo-gowo-mobile" alt="logo-gowo-mobile-small.png">
                </a>
            </div>
            <div class="str-header" id="str-header" onclick="toTop()">
                <img class="str-img-bar" src="../../../assets/images/all-images/store-profile/benditopet.jpg">
                <div class="str-name-bar-string">BenditoPet</div>
                <!--
                <input type="text" placeholder="Benditogowo" disabled="true" class="str-name-bar">
                -->
            </div>
        </div>
        <div class="bar hidden-md hidden-lg" id="bar-store">
            <div class="topics" id="topics">
                <a href="#topic1"><div id="topicLink1" class="topic-item firstTopic">Rações</div></a>
                <a href="#topic2"><div id="topicLink2" class="topic-item">Brinquedos</div></a>
                <a href="#topic3"><div id="topicLink3" class="topic-item">Higiene e Limpeza</div></a>
                <a href="#topic4"><div id="topicLink4" class="topic-item">Acessórios</div></a>
                <a href="#topic5"><div id="topicLink5" class="topic-item">Gaiolas</div></a>
                <a href="#topic6"><div id="topicLink6" class="topic-item">Serviços</div></a>
            </div>
        </div>
    </div>
    <div class="navbar-extends hidden-xs hidden-sm">
        <div class="bar-white">
            <a href="../../store"><img src="../../../assets/images/logos/logo-gowo-h120.png" class="logo-name-gowo" alt="logo-name-gowo-small.png" draggable="false"></a>
            <div class="navigation-items" id="navigation-items">
                <div class="nav-item active-item" onclick="navRedSecond(1)">Início</div>
                <div class="nav-item" onclick="navRedSecond(2)">Buscar</div>
                <div class="nav-item" onclick="navRedSecond(3)">Recentes</div>
                <div class="nav-item" onclick="navRedSecond(4)">Perfil</div>
            </div>
        </div>
        <div class="icon-navbar" onclick="redirect(3)"><i data-feather="shopping-bag"  class='cart-icon-up'></i><div class="number-notification" id='cart-counter'>3</div></div>
    </div>
    <div class="space-top-large hidden-xs hidden-sm"></div>
    <div class="space-top-small hidden-md hidden-lg"></div>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div style="
                    background: url('../../../assets/images/all-images/profile-cover/bendito-gowo.jpg');
                    background-position: center;
                    background-repeat: no-repeat;
                    background-size: cover;
                    height: 200px;
                    margin-left: -15px;
                    margin-top: -20px;
                    margin-right: -15px;
                ">
                </div>
            </div>
        </div>
    </div>
</div>
    
    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <center><img class="img-store" src="../../../assets/images/all-images/store-profile/benditopet.jpg" draggable="false"></img></center>
                <div class="store-title">BenditoPet</div>
                <div class="store-subtitle">Pet Shop</div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
    <div class="container" style="margin-top: 25px;">
        <div class="row">
            <div class="col-md-3 col-sm-12">
                <div class="floating-box" id="box-inf">

                <div class="inf-profile" id="inf-profile">
                    <img class="profile-img-inf" src="../../../assets/images/all-images/store-profile/benditopet.jpg">
                    <div class='profile-name-inf'>BenditoPet</div>
                </div>

                <div class="inf-topic-1">
                    <i data-feather="map-pin"  class='icon-inf'></i>
                    <div class="inf-text" id="map-inf" style="cursor = pointer;" onclick="redirectMaps('R. Agenor Amaro dos Santos, 201 - Loja 04 - Jardim Camburi, Vitória - ES, 29090-010')">R. Agenor Amaro dos Santos, 201 - Loja 04 - Jardim Camburi, Vitória - ES, 29090-010<div class="clickRedirect">(ir para o mapa)</div></div>
                </div>

                <div class="inf-topic">
                    <i data-feather="phone-call"  class='icon-inf'></i>
                    <div class="inf-text" id="tel-inf">(27) 3029-1469</div>
                </div>

                <div class="inf-topic">
                <i data-feather="facebook"  class='icon-inf'></i>
                    <div class="inf-text" id="fac-inf"><a href="https://www.facebook.com/benditopet" target="_blank">/BenditoPet</a></div>
                </div>

                <div class="inf-topic">
                    <i data-feather="instagram"  class='icon-inf'></i>
                    <div class="inf-text" id="int-inf"><a href="https://www.instagram.com/benditopey/" target="_blank">@BenditoPet</a></div>
                </div>

                <div class="hidden-xs hidden-sm">
<!--
                <div class='profile-title-inf'><i data-feather="filter" class="icon-profile"></i>Filtros</div>

                <div class="filter-item">
                    <label>Cachorro
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="filter-item">
                    <label>Gatos
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="filter-item">
                    <label>Aves
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="filter-item">
                    <label>Roedores
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="filter-item">
                    <label>Diversos
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
-->
                </div>
                </div>
                
            </div>
            <div class="col-md-8 right-content">
                <div classs="topic-prd" id="topic1">
                    <div class="service-title">Rações</div>

                    <a href="productmodel.php">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/1.jpg">
                        <div class="product-inf">
                            <div class="name-product">Ração Premier Golden Special Cães Adultos Frango e Carne</div>
                            <div class="desc-product">Cachorro</div>
                            <div class="price-product">R$ 135,90</div>
                        </div>
                    </div>
                    </a>

                    <a href="#">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/9.jpg">
                        <div class="product-inf">
                            <div class="name-product">Mistura de Sementes Nutricon Nutriseeds</div>
                            <div class="desc-product">Roedores</div>
                            <div class="price-product">R$ 21,30</div>
                        </div>
                    </div>
                    </a>

                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/2.jpg">
                        <div class="product-inf">
                            <div class="name-product">Ração Golden Gatos Adultos Carne</div>
                            <div class="desc-product">Gatos</div>
                            <div class="price-product">R$ 102,90</div>
                        </div>
                    </div>

                </div>
                <div classs="topic-prd" id="topic2">
                    <div class="service-title">Brinquedos</div>

                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/3.jpg">
                        <div class="product-inf">
                            <div class="name-product">Brinquedo American Pets Bolinha Inteligente</div>
                            <div class="desc-product">Cachorro</div>
                            <div class="price-product">R$ 21,90</div>
                        </div>
                    </div>

                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/10.jpg">
                        <div class="product-inf">
                            <div class="name-product">Brinquedo AFP Green Rush Ratos com Catnip para Gatos</div>
                            <div class="desc-product">Gatos</div>
                            <div class="price-product">R$ 46,90</div>
                        </div>
                    </div>

                </div>

                <div classs="topic-prd" id="topic3">
                    <div class="service-title">Higiene e Limpeza</div>

                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/4.jpg">
                        <div class="product-inf">
                            <div class="name-product">Areia Sanitária Kelco Pipicat Multicat - 12 Kg</div>
                            <div class="desc-product">Gatos</div>
                            <div class="price-product">R$ 31,90</div>
                        </div>
                    </div>

                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/7.jpg">
                        <div class="product-inf">
                            <div class="name-product">Tagowoe Higiênico Super Secão</div>
                            <div class="desc-product">Cachorro</div>
                            <div class="price-product">R$ 66,90</div>
                        </div>
                    </div>

                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/8.jpg">
                        <div class="product-inf">
                            <div class="name-product">Areia Higiênica ProGato para Pássaros</div>
                            <div class="desc-product">Aves</div>
                            <div class="price-product">R$ 15,90</div>
                        </div>
                    </div>

                </div>

                <div classs="topic-prd" id="topic4">
                    <div class="service-title">Acessórios</div>

                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/5.jpg">
                        <div class="product-inf">
                            <div class="name-product">Alimentador American Pets Eletrônico e Programável Premium</div>
                            <div class="desc-product">Diversos</div>
                            <div class="price-product">R$ 389,90</div>
                        </div>
                    </div>

                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/6.jpg">
                        <div class="product-inf">
                            <div class="name-product">Almofada Retangular Lisa de Microfibra - Rosa</div>
                            <div class="desc-product">Cachorros</div>
                            <div class="price-product">R$ 39,90</div>
                        </div>
                    </div>

                </div>

                <div classs="topic-prd" id="topic5">
                    <div class="service-title">Gaiolas</div>

                    <a href="#">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/11.jpg">
                        <div class="product-inf">
                            <div class="name-product">Criadeira Bragança para Periquitos</div>
                            <div class="desc-product">Aves</div>
                            <div class="price-product">R$ 99,90</div>
                        </div>
                    </div>
                    </a>

                    <a href="#">    
                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/12.jpg">
                        <div class="product-inf">
                            <div class="name-product">Ninho Animalíssimo Sisal para Pássaros</div>
                            <div class="desc-product">Aves</div>
                            <div class="price-product">R$ 23,90</div>
                        </div>
                    </div>
                    </a>

                </div>

                <div classs="topic-prd" id="topic6">
                    <div class="service-title">Serviços</div>

                    <a href="#">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/13.jpg">
                        <div class="product-inf">
                            <div class="name-product">Banho e Tosa</div>
                            <div class="desc-product">Cachorro</div>
                            <div class="price-product">R$ 50,00</div>
                        </div>
                    </div>
                    </a>

                    <a href="#">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/14.jpg">
                        <div class="product-inf">
                            <div class="name-product">Diária Hotel - Animais Pequenos</div>
                            <div class="desc-product">Diversos</div>
                            <div class="price-product">R$ 63,90</div>
                        </div>
                    </div>
                    </a>

                    <a href="#">    
                    <div class="box-product">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/14.jpg">
                        <div class="product-inf">
                            <div class="name-product">Diária Hotel - Animais Médios</div>
                            <div class="desc-product">Diversos</div>
                            <div class="price-product">R$ 75,90</div>
                        </div>
                    </div>
                    </a>

                    <a href="#">    
                    <div class="box-product last-box">
                        <img class="img-product" src="../../../assets/images/all-images/product-images/00000001/14.jpg">
                        <div class="product-inf">
                            <div class="name-product">Diária Hotel - Animais Grandes</div>
                            <div class="desc-product">Diversos</div>
                            <div class="price-product">R$ 93,90</div>
                        </div>
                    </div>
                    </a>

                </div>


            </div>
        </div>
    </div>
<script>
    feather.replace();
</script>
</body>
</html>