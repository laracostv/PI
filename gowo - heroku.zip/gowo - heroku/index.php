<?php
session_start();
if(isset($_SESSION['email'])){
    header('Location: views/store');
}

  $erro = isset($_GET['erro']) ? $_GET['erro'] : 0;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>GoWo</title>
  <meta charset="utf-8">
  <!--meta tags index-->
  <meta property="og:locale" content="pt_BR">
  <meta property="og:url" content="https://gowoifes.herokuapp.com/">
  <meta property="og:title" content="GoWo">
  <meta property="og:site_name" content="Gowo">
  <meta property="og:description" content="">
  <meta property="og:image" content="https://gowoifes.herokuapp.com/assets/icons/apple-touch-icon.png">
  <meta property="og:image:type" content="image/jpg">
  <meta property="og:image:width" content="260">
  <meta property="og:image:height" content="260">
  <meta property="og:type" content="website">
  <!--BOOTSTRAP IMPORT-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-png">
  <!--FAVICONS-->
  <link rel="shortcut icon" href="assets/icons/favicon-512x512.png" type="image/x-png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/icons/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/icons/favicon-16x16.png">
  <link rel="manifest" href="assets/icons/site.webmanifest">
  <link rel="mask-icon" href="assets/icons/safari-pinned-tab.svg" color="#ffffff">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="theme-color" content="#ffffff">
  <!--CSS-->
  <link rel="stylesheet" type="text/css" href="public/css/general.css">
  <link rel="stylesheet" type="text/css" href="public/css/newindex.css">
  <!--SCRIPTS-->
  <script type="text/javascript" src="public/script/index.js"></script> 
  <!--FONTS-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700|Open+Sans|Open+Sans+Condensed:300,700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!--SWEET ALERT-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

</head>
<body id="fundo">
<script>

</script>
<a href="views/inicial/store_register_page.php">
  <div id="cad-rst" class="cad-rst">Seja Parceiro</div>
</a>
<div class="container align-items-center align-middle">
    <div class="row">
      <div class="col-md-2 col-lg-3">
      </div>
      <div class="col-md-8 col-lg-6">
      <center>
          <img src="assets/images/logos/logo-gowo-h120.png" class="logo-gowo">
        </center>
        <center>
          <div class="center-box">
            <div class="box">
            <form id="login-form" method="post" action="data_base/login_validation.php">
            <div class="input-container">
                    <input id="userEmail" name="user" class="input" type="text" placeholder="Email" required />
                    <label class="label" for="userEmail">Email</label>
            </div>
            <div class="input-container">
                    <input id="pasw" name="pwd" class="input" type="password" placeholder="******" required />
                    <label class="label" for="pasw">Senha</label>
            </div>
            <!--
              <input type="text" id="userEmail" name="user" placeholder="Email">
              <input type="password" id="pasw" name="pwd" placeholder="Senha">
            -->
              <?php
                if($erro == 1){
                  echo'<div class="text-erro" id="text-erro">Usuário e/ou senha incorretos</div>';
                }
                if($erro == 2){
                  echo"<script>
                  $(document).ready(function(){
                      responsive();
                      alertMenssage();
                    });
                  </script>";
                }
              ?>
              <div class="text-erro" id="text-erro"></div>
              <input type="submit" value="Entrar" name="submit" class="but" id="btnLogin">
            </form>
            <div class="text-cad">Ainda não possui conta?</div>
            <a href="views/inicial/cadastro.php" class="cad-click">Cadastre-se</a>
        </center>
      </div>
    </div>
 </div>
  <div id="bar-down" class="bar-down">
    <div></div>
  <center><a href="views/inicial/store_register_page.php"><button class="cad-rst-center">Seja parceiro</button></a></center>
  </div>
</body>
</html>